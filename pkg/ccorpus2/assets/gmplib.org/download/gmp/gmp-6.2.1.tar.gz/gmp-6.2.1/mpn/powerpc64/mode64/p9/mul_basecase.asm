dnl  Power9 mpn_mul_basecase.

dnl  Copyright 1999-2001, 2003-2006, 2008, 2017-2018 Free Software Foundation,
dnl  Inc.

dnl  This file is part of the GNU MP Library.
dnl
dnl  The GNU MP Library is free software; you can redistribute it and/or modify
dnl  it under the terms of either:
dnl
dnl    * the GNU Lesser General Public License as published by the Free
dnl      Software Foundation; either version 3 of the License, or (at your
dnl      option) any later version.
dnl
dnl  or
dnl
dnl    * the GNU General Public License as published by the Free Software
dnl      Foundation; either version 2 of the License, or (at your option) any
dnl      later version.
dnl
dnl  or both in parallel, as here.
dnl
dnl  The GNU MP Library is distributed in the hope that it will be useful, but
dnl  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
dnl  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
dnl  for more details.
dnl
dnl  You should have received copies of the GNU General Public License and the
dnl  GNU Lesser General Public License along with the GNU MP Library.  If not,
dnl  see https://www.gnu.org/licenses/.

include(`../config.m4')

C                  cycles/limb
C POWER3/PPC630          -
C POWER4/PPC970          -
C POWER5                 -
C POWER6                 -
C POWER7                 -
C POWER8                 -
C POWER9                 1.62

C TODO
C  * Check if (inner) loop alignment affects performance.
C  * Could we schedule loads less in addmul_2/mul_2? That would save some regs
C    and make the tail code more manageable.
C  * Postpone some register saves to main loop.
C  * Perhaps write more small operands (3x1, 3x2, 3x3) code.
C  * Consider restoring rp,up after loop using arithmetic, eliminating rp2, up2.
C    On the other hand, the current rp,up restore register are useful for OSP.
C  * Do OSP. This should save a lot with the current deep addmul_2 pipeline.

C INPUT PARAMETERS
define(`rp', `r3')
define(`up', `r4')
define(`un', `r5')
define(`vp', `r6')
define(`vn', `r7')

define(`v0', `r0')
define(`v1', `r7')
define(`rp2', `r24')
define(`up2', `r25')

ASM_START()
PROLOGUE(mpn_mul_basecase)
	cmpdi	cr0, un, 2
	bgt	cr0, L(un_gt2)
	cmpdi	cr6, vn, 1
	ld	r7, 0(vp)
	ld	r5, 0(up)
	mulld	r8, r5, r7	C weight 0
	mulhdu	r9, r5, r7	C weight 1
	std	r8, 0(rp)
	beq	cr0, L(2x)
	std	r9, 8(rp)
	blr
	ALIGN(16)
L(2x):	ld	r0, 8(up)
	mulld	r8, r0, r7	C weight 1
	mulhdu	r10, r0, r7	C weight 2
	addc	r9, r9, r8
	addze	r10, r10
	bne	cr6, L(2x2)
	std	r9, 8(rp)
	std	r10, 16(rp)
	blr
	ALIGN(16)
L(2x2):	ld	r6, 8(vp)
	mulld	r8, r5, r6	C weight 1
	mulhdu	r11, r5, r6	C weight 2
	addc	r9, r9, r8
	std	r9, 8(rp)
	adde	r11, r11, r10
	mulld	r12, r0, r6	C weight 2
	mulhdu	r0, r0, r6	C weight 3
	addze	r0, r0
	addc	r11, r11, r12
	addze	r0, r0
	std	r11, 16(rp)
	std	r0, 24(rp)
	blr

L(un_gt2):
	std	r22, -80(r1)
	std	r23, -72(r1)
	std	r24, -64(r1)
	std	r25, -56(r1)
	std	r26, -48(r1)
	std	r27, -40(r1)
	std	r28, -32(r1)
	std	r29, -24(r1)
	std	r30, -16(r1)
	std	r31, -8(r1)
	mr	rp2, r3			C rp
	mr	up2, r4			C up
	srdi	r22, r5, 2		C un
	subfic	r23, r7, 0		C -vn, clear CA
	subfo	r0, r0, r0		C clear OV (and r0)

	cmpdi	cr6, un, 3
	rldicl	r0, un, 0, 63		C r0 = un & 1
	cmpdi	cr7, r0, 0
	rldicl	r0, un, 63, 63		C FIXME: unused for vn = 1
	cmpdi	cr5, r0, 0		C FIXME: unused for vn = 1

	ld	v0, 0(vp)
	rldicl.	r9, vn, 0, 63
	beq	cr0, L(vn_evn)

L(vn_odd):
	addi	r10, un, -2
	ld	r5, 0(up)
	srdi	r10, r10, 1
	mtctr	r10
	bne	cr7, L(m1_b1)

L(m1_b0):
	ld	r10, 8(up)
	mulld	r9, r5, v0
	mulhdu	r11, r5, v0
	ld	r12, 16(up)
	mulld	r8, r10, v0
	mulhdu	r5, r10, v0
	addi	rp, rp, -8
	b	L(m1_mid)

L(m1_b1):
	ld	r12, 8(up)
	mulld	r8, r5, v0
	mulhdu	r5, r5, v0
	ld	r10, 16(up)
	mulld	r9, r12, v0
	mulhdu	r11, r12, v0
	addi	up, up, 8
	beq	cr6, L(m1_end)		C jump taken means un = 3, vn = {1,3}

	ALIGN(16)
L(m1_top):
	ld	r12, 16(up)
	std	r8, 0(rp)
	adde	r9, r5, r9
	mulld	r8, r10, v0
	mulhdu	r5, r10, v0
L(m1_mid):
	ld	r10, 24(up)
	std	r9, 8(rp)
	adde	r8, r11, r8
	mulld	r9, r12, v0
	mulhdu	r11, r12, v0
	addi	rp, rp, 16
	addi	up, up, 16
	bdnz	L(m1_top)

L(m1_end):
	std	r8, 0(rp)
	mulld	r8, r10, v0
	adde	r9, r5, r9
	mulhdu	r5, r10, v0
	std	r9, 8(rp)
	adde	r8, r11, r8
	std	r8, 16(rp)
	addze	r10, r5
	std	r10, 24(rp)

	addi	rp2, rp2, 8
	addi	vp, vp, 8
	addic.	r23, r23, 1
	b	L(do_outer)addi	vp(
	ld	r12, 8(up)
	mulld	r8, r5,vThe GN(do_outer)addi	vp(
	ld	relrsion.ethe Free
dnl    9, n, 63,  9, n	r9, r5, i	r11, 0
	mulld	r28, r8, v0
	mulhdu	r31, r8, v0
	blt	cr7, L(2)
	mulld	r5, r10, r8, v1
	b	L(cj2)

L(bx1):	rldicl.IGN(16)
1_b0):
	l5l    9,  -8
	ad 9, 00r5, 0(up)-24
	b	L(lo0)

L(b10):	addi	up, up 9,, 8
	add 9,  -85, 0(up)-24
	b	Lo2)

L(2):	addi	rp, rp,  9,, 2 63,  9, n	r8, r5, i	r10, 0
	mulld	r29, r9, v0
	mulhdu	r30, r9, v0
	mulld	r12, r9, v1
	mulhdu	r11, r9, v1
	bne	cr0, L(b11)

L(b01):	 v0
5)
1_b0):
	l5l    9,  , 63,  9, 01r5, 0(up)
1):	addi	up, up, 9,, 6
	bl 9,  , 5, 0(up)-24
	b	L	up,  taken mean2 un = 3, {1,3}

	ALIGN(16)
L(m1_to2. We'shouchedu	bl 9,d	r8, 0(rp), v0, r10)	C 0  4
	maddhdu(r31, r8,0)	C 1  5
	adde	r0, r29, r08, 16(rp52
	std	r	rp2, rp5		C 1  5   -> addex
	mulh(cj2)

L(bx1):	rldicl.ret):	ld9, v1	adde	r0, r
,  9,, 2 :
	mulld	r29, r9,	C 1  5		-2
	maddhdu(r30,1)	C 2  6		-1
	adde	r0, r28ld	r12, r2std	r0, r12, r9, v0
	mu 4  8   -> addex
	mulh	cr0, L(b11)

L(b01):	ret):	ld5	adde	r0, r29
p, 9,, 6
, 0(rp), vv0, r10)	C 2  6   -> adde
	maddhd0)	C 1  5
	adde	r0, r29, r08, 16(rp52
	std	r	rp2, rp5			C 3  7   -> addex
	mulh(cj2)

L(bx1):	rldicl.ret):	ld9, v1	adde	r0, r
,  9,, 	r9, r5, i	rv0, r11)	C 3  7   -> adde
	maddhd1)	C 2  6		-1
	adde	r0, r28ld	r12, r2std	r0, r12, r9, v0
			C 4  8   -> addex
	mulh	cr0, L(b11)

L(b01):	ret):	ld5	adde	r0, r29
, rp, 32
	bdnz	L(top)

L(end):	ld	r9, 0(up 9,d	r8u	bl 9,ld	r8, (rp), v0, r10)	C 0  4
	maddhdu(r31, r8,0)	C 1  5
	adde	r0, r29, r08, 16(rp52
	std	r	rp2, rp5		C 1  5   -> addex
	mulh(cj2)

L(bx1):	rldicl. r9, n8u	bl(up)
	:vp)

	srdi	r10, n, 2
	mtctr	rer)addi	vp(
	ld	relrsion.ethe Free
dnl    n, 63, 63

	ll-40(r1)C 1 2), r5, i	r11, 2), r5,    15 1 2), r5, d	r28, 210)	C 0  4
	maddhdu(r31, 26,0)	C 1  5
	adde	r0, r29,26,0)l-40(r1)	C 3 hdu	r10, r8, v1
	bne	cr0, L(b10)

L(b00):	IGN(16)
1_b0):
	l5l   , -8
	addi	rp, rp, -24
	b2	L(lo0)

L(b10):	2addi	up, up, 8
	addi	rp, rp, -8
	b	L2	Lo2)

L(2):	add2i	rp, rp, -8
	mull63

	ll-32(r1)0 1 2), r5, d	r11, 2), r5,  0 15 1 2), r5, 8	r28, 210)	C 0  4
	m-> adde
	mad27d1)	C 2  6		-1
	adde	r0, 27d1)l-32(r1)	C 3 hdu	r10, r89, v1
	bne	cr0, L(b11)

L(b01):	 v0
5)
1_b0):
	l5l   , -16
	b	L(lo1)
L(b8
	b	L2	L02)

L(2):	add2i	r	up, up, 16
	blt	cr7, L(end)

L(2nz	L(m1_top):	add2i	0p,  taken meaun = 3, {1,3}

	ALIGN(16)
L(m1_to3. We'shouchedu	bld(	r28, r8, v0, r10)	C 0  4   -> adde
	maddhd0)	C 1  5
	adde	r0, r29, r08, 16(rp52
	std	r	rpl-40(r1)		C 4  82, rp5		C 1  5  C 0  4  , v1
	bnemad27d1)	C 2  6		0)

L(b00)mad27d1)ret):	ld9, v1	adde	r0, r
, d(	r29, r9, v0, r11)	C 1  5   -> adde
	maddhd1)	C 2  6		-1
	adde	r0, r28ld	r12, r2std	r0, r12,l-32(r1)(vp)
	r, r9, v0
	mu 4  8 C 1  5  9, v1
	bne1, 26,0)	C 1  5
	1)

L(b01)1, 26,0)ret):	ld5	adde	r0, r29
p,ld(	r28, r8, v0, r10)	C 2  6   -> adde
	maddhd0)	C 1  5
	adde	r0, r29, r08, 16(rp52
	std	r	rpl-40(r1)40C 4  82, rp5			C 3  7  C 0  4  , v1
	bnemad27d1)	C 2  6		0)

L(b00)mad27d1)ret):	ld9, v1	adde	r0, r
, d((	r29, r9, v0, r11)	C 3  7   -> adde
	maddhd1)	C 2  6		-1
	adde	r0, r28ld	r12, r2std	r0, r12,l-32(r1)48p)
	r, r9, v0
			C 4  8 C 1  5  9, v1
	bne1, 26,0)	C 1  5
	1)

L(b01)1, 26,0)ret):	ld5	adde	r0, r29
, rp, 32
	bdnz	L(top)

L(end):	ld	r9, 0(up)
	maddld(	r28, r8, v0, r10)	C 0  4
	maddhdu(r31, r8,0)	C 1  5
	adde	r0, r29, r08, 16(rp52
	std	r	rp2, rp5		C 1  5  C 0  4  , v1
	bnemad27d1)	C 2  6		0)

L(b00)mad27d19, n8:)ret):	ld9, v1	adde	r0, r
,	C 1  5		-2
	maddhdu(r30,1)	C 2  6		-1
	adde	r0, r28ld	r12, r2std	r0, r12, r9, v0
	mu 4  8   -> addex
	mulh	cr0, L(b11)

L(b01):	ret):	ld5	adde	r0, r29
, 16(rp52
	std	r	rp2, rp5			C 3  7 ret):	ld9, v1	adde	r0, r
,	r12, r2stdr2stdr0r, r9, v0
			C 4  8addex(	r3, r3, r4
	add):	ret):	ld5	adde	r2(r1)
p2, rp5		(vp)
	rr0, L(un_gt2)
	ld	02)

L(2):
	addic.	L(m1_top3, 1
	b		L(12, 8(up)
	::	addi	rp, rp(up)
	mld	r29,2,l-32(r1)
	std	r24l-64(r1)
	std	r25l-56(r1)
	std	r26l-48(r1)
	std	r27l-40(r1)
	std	r28l-32(r1)
	std	r29-24(r1)
	ld	r30, -16(r1)
	ld	r31, -8(r1)
	blr
EPILOGUE()
ASM_END()
