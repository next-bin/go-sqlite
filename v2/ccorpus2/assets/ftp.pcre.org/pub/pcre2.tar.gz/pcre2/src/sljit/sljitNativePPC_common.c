/*
 *    Stack-less Just-In-Time compiler
 *
 *    Copyright Zoltan Herczeg (hzmester@freemail.hu). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 *
 *   1. Redistributions of source code must retain the above copyright notice, this list of
 *      conditions and the following disclaimer.
 *
 *   2. Redistributions in binary form must reproduce the above copyright notice, this list
 *      of conditions and the following disclaimer in the documentation and/or other materials
 *      provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER(S) AND CONTRIBUTORS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE COPYRIGHT HOLDER(S) OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

SLJIT_API_FUNC_ATTRIBUTE const char* sljit_get_platform_name(void)
{
	return "PowerPC" SLJIT_CPUINFO;
}

/* Length of an instruction word.
   Both for ppc-32 and ppc-64. */
typedef sljit_u32 sljit_ins;

#if ((defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32) && (defined _AIX)) \
	|| (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
#define SLJIT_PPC_STACK_FRAME_V2 1
#endif

#ifdef _AIX
#include <sys/cache.h>
#endif

#if (defined _CALL_ELF && _CALL_ELF == 2)
#define SLJIT_PASS_ENTRY_ADDR_TO_CALL 1
#endif

#if (defined SLJIT_CACHE_FLUSH_OWN_IMPL && SLJIT_CACHE_FLUSH_OWN_IMPL)

static void ppc_cache_flush(sljit_ins *from, sljit_ins *to)
{
#ifdef _AIX
	_sync_cache_range((caddr_t)from, (int)((size_t)to - (size_t)from));
#elif defined(__GNUC__) || (defined(__IBM_GCC_ASM) && __IBM_GCC_ASM)
#	if defined(_ARCH_PWR) || defined(_ARCH_PWR2)
	/* Cache flush for POWER architecture. */
	while (from < to) {
		__asm__ volatile (
			"clf 0, %0\n"
			"dcs\n"
			: : "r"(from)
		);
		from++;
	}
	__asm__ volatile ( "ics" );
#	elif defined(_ARCH_COM) && !defined(_ARCH_PPC)
#	error "Cache flush is not implemented for PowerPC/POWER common mode."
#	else
	/* Cache flush for PowerPC architecture. */
	while (from < to) {
		__asm__ volatile (
			"dcbf 0, %0\n"
			"sync\n"
			"icbi 0, %0\n"
			: : "r"(from)
		);
		from++;
	}
	__asm__ volatile ( "isync" );
#	endif
#	ifdef __xlc__
#	warning "This file may fail to compile if -qfuncsect is used"
#	endif
#elif defined(__xlc__)
#error "Please enable GCC syntax for inline assembly statements with -qasm=gcc"
#else
#error "This platform requires a cache flush implementation."
#endif /* _AIX */
}

#endif /* (defined SLJIT_CACHE_FLUSH_OWN_IMPL && SLJIT_CACHE_FLUSH_OWN_IMPL) */

#define TMP_REG1	(SLJIT_NUMBER_OF_REGISTERS + 2)
#define TMP_REG2	(SLJIT_NUMBER_OF_REGISTERS + 3)
#define TMP_ZERO	(SLJIT_NUMBER_OF_REGISTERS + 4)

#if (defined SLJIT_PASS_ENTRY_ADDR_TO_CALL && SLJIT_PASS_ENTRY_ADDR_TO_CALL)
#define TMP_CALL_REG	(SLJIT_NUMBER_OF_REGISTERS + 5)
#else
#define TMP_CALL_REG	TMP_REG2
#endif

#define TMP_FREG1	(SLJIT_NUMBER_OF_FLOAT_REGISTERS + 1)
#define TMP_FREG2	(SLJIT_NUMBER_OF_FLOAT_REGISTERS + 2)

static const sljit_u8 reg_map[SLJIT_NUMBER_OF_REGISTERS + 7] = {
	0, 3, 4, 5, 6, 7, 8, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 1, 9, 10, 31, 12
};

static const sljit_u8 freg_map[SLJIT_NUMBER_OF_FLOAT_REGISTERS + 3] = {
	0, 1, 2, 3, 4, 5, 6, 0, 7
};

/* --------------------------------------------------------------------- */
/*  Instrucion forms                                                     */
/* --------------------------------------------------------------------- */
#define D(d)		(reg_map[d] << 21)
#define S(s)		(reg_map[s] << 21)
#define A(a)		(reg_map[a] << 16)
#define B(b)		(reg_map[b] << 11)
#define C(c)		(reg_map[c] << 6)
#define FD(fd)		(freg_map[fd] << 21)
#define FS(fs)		(freg_map[fs] << 21)
#define FA(fa)		(freg_map[fa] << 16)
#define FB(fb)		(freg_map[fb] << 11)
#define FC(fc)		(freg_map[fc] << 6)
#define IMM(imm)	((imm) & 0xffff)
#define CRD(d)		((d) << 21)

/* Instruction bit sections.
   OE and Rc flag (see ALT_SET_FLAGS). */
#define OE(flags)	((flags) & ALT_SET_FLAGS)
/* Rc flag (see ALT_SET_FLAGS). */
#define RC(flags)	(((flags) & ALT_SET_FLAGS) >> 10)
#define HI(opcode)	((opcode) << 26)
#define LO(opcode)	((opcode) << 1)

#define ADD		(HI(31) | LO(266))
#define ADDC		(HI(31) | LO(10))
#define ADDE		(HI(31) | LO(138))
#define ADDI		(HI(14))
#define ADDIC		(HI(13))
#define ADDIS		(HI(15))
#define ADDME		(HI(31) | LO(234))
#define AND		(HI(31) | LO(28))
#define ANDI		(HI(28))
#define ANDIS		(HI(29))
#define Bx		(HI(18))
#define BCx		(HI(16))
#define BCCTR		(HI(19) | LO(528) | (3 << 11))
#define BLR		(HI(19) | LO(16) | (0x14 << 21))
#define CNTLZD		(HI(31) | LO(58))
#define CNTLZW		(HI(31) | LO(26))
#define CMP		(HI(31) | LO(0))
#define CMPI		(HI(11))
#define CMPL		(HI(31) | LO(32))
#define CMPLI		(HI(10))
#define CROR		(HI(19) | LO(449))
#define DCBT		(HI(31) | LO(278))
#define DIVD		(HI(31) | LO(489))
#define DIVDU		(HI(31) | LO(457))
#define DIVW		(HI(31) | LO(491))
#define DIVWU		(HI(31) | LO(459))
#define EXTSB		(HI(31) | LO(954))
#define EXTSH		(HI(31) | LO(922))
#define EXTSW		(HI(31) | LO(986))
#define FABS		(HI(63) | LO(264))
#define FADD		(HI(63) | LO(21))
#define FADDS		(HI(59) | LO(21))
#define FCFID		(HI(63) | LO(846))
#define FCMPU		(HI(63) | LO(0))
#define FCTIDZ		(HI(63) | LO(815))
#define FCTIWZ		(HI(63) | LO(15))
#define FDIV		(HI(63) | LO(18))
#define FDIVS		(HI(59) | LO(18))
#define FMR		(HI(63) | LO(72))
#define FMUL		(HI(63) | LO(25))
#define FMULS		(HI(59) | LO(25))
#define FNEG		(HI(63) | LO(40))
#define FRSP		(HI(63) | LO(12))
#define FSUB		(HI(63) | LO(20))
#define FSUBS		(HI(59) | LO(20))
#define LD		(HI(58) | 0)
#define LWZ		(HI(32))
#define MFCR		(HI(31) | LO(19))
#define MFLR		(HI(31) | LO(339) | 0x80000)
#define MFXER		(HI(31) | LO(339) | 0x10000)
#define MTCTR		(HI(31) | LO(467) | 0x90000)
#define MTLR		(HI(31) | LO(467) | 0x80000)
#define MTXER		(HI(31) | LO(467) | 0x10000)
#define MULHD		(HI(31) | LO(73))
#define MULHDU		(HI(31) | LO(9))
#define MULHW		(HI(31) | LO(75))
#define MULHWU		(HI(31) | LO(11))
#define MULLD		(HI(31) | LO(233))
#define MULLI		(HI(7))
#define MULLW		(HI(31) | LO(235))
#define NEG		(HI(31) | LO(104))
#define NOP		(HI(24))
#define NOR		(HI(31) | LO(124))
#define OR		(HI(31) | LO(444))
#define ORI		(HI(24))
#define ORIS		(HI(25))
#define RLDICL		(HI(30))
#define RLWINM		(HI(21))
#define SLD		(HI(31) | LO(27))
#define SLW		(HI(31) | LO(24))
#define SRAD		(HI(31) | LO(794))
#define SRADI		(HI(31) | LO(413 << 1))
#define SRAW		(HI(31) | LO(792))
#define SRAWI		(HI(31) | LO(824))
#define SRD		(HI(31) | LO(539))
#define SRW		(HI(31) | LO(536))
#define STD		(HI(62) | 0)
#define STDU		(HI(62) | 1)
#define STDUX		(HI(31) | LO(181))
#define STFIWX		(HI(31) | LO(983))
#define STW		(HI(36))
#define STWU		(HI(37))
#define STWUX		(HI(31) | LO(183))
#define SUBF		(HI(31) | LO(40))
#define SUBFC		(HI(31) | LO(8))
#define SUBFE		(HI(31) | LO(136))
#define SUBFIC		(HI(8))
#define XOR		(HI(31) | LO(316))
#define XORI		(HI(26))
#define XORIS		(HI(27))

#define SIMM_MAX	(0x7fff)
#define SIMM_MIN	(-0x8000)
#define UIMM_MAX	(0xffff)

#define RLDI(dst, src, sh, mb, type) \
	(HI(30) | S(src) | A(dst) | ((type) << 2) | (((sh) & 0x1f) << 11) | (((sh) & 0x20) >> 4) | (((mb) & 0x1f) << 6) | ((mb) & 0x20))

#if (defined SLJIT_INDIRECT_CALL && SLJIT_INDIRECT_CALL)
SLJIT_API_FUNC_ATTRIBUTE void sljit_set_function_context(void** func_ptr, struct sljit_function_context* context, sljit_sw addr, void* func)
{
	sljit_sw* ptrs;
	if (func_ptr)
		*func_ptr = (void*)context;
	ptrs = (sljit_sw*)func;
	context->addr = addr ? addr : ptrs[0];
	context->r2 = ptrs[1];
	context->r11 = ptrs[2];
}
#endif

static sljit_s32 push_inst(struct sljit_compiler *compiler, sljit_ins ins)
{
	sljit_ins *ptr = (sljit_ins*)ensure_buf(compiler, sizeof(sljit_ins));
	FAIL_IF(!ptr);
	*ptr = ins;
	compiler->size++;
	return SLJIT_SUCCESS;
}

static SLJIT_INLINE sljit_s32 detect_jump_type(struct sljit_jump *jump, sljit_ins *code_ptr, sljit_ins *code, sljit_sw executable_offset)
{
	sljit_sw diff;
	sljit_uw target_addr;
	sljit_sw extra_jump_flags;

#if (defined SLJIT_PASS_ENTRY_ADDR_TO_CALL && SLJIT_PASS_ENTRY_ADDR_TO_CALL) && (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
	if (jump->flags & (SLJIT_REWRITABLE_JUMP | IS_CALL))
		return 0;
#else
	if (jump->flags & SLJIT_REWRITABLE_JUMP)
		return 0;
#endif

	if (jump->flags & JUMP_ADDR)
		target_addr = jump->u.target;
	else {
		SLJIT_ASSERT(jump->flags & JUMP_LABEL);
		target_addr = (sljit_uw)(code + jump->u.label->size) + (sljit_uw)executable_offset;
	}

#if (defined SLJIT_PASS_ENTRY_ADDR_TO_CALL && SLJIT_PASS_ENTRY_ADDR_TO_CALL) && (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (jump->flags & IS_CALL)
		goto keep_address;
#endif

	diff = ((sljit_sw)target_addr - (sljit_sw)(code_ptr) - executable_offset) & ~0x3l;

	extra_jump_flags = 0;
	if (jump->flags & IS_COND) {
		if (diff <= 0x7fff && diff >= -0x8000) {
			jump->flags |= PATCH_B;
			return 1;
		}
		if (target_addr <= 0xffff) {
			jump->flags |= PATCH_B | PATCH_ABS_B;
			return 1;
		}
		extra_jump_flags = REMOVE_COND;

		diff -= sizeof(sljit_ins);
	}

	if (diff <= 0x01ffffff && diff >= -0x02000000) {
		jump->flags |= PATCH_B | extra_jump_flags;
		return 1;
	}

	if (target_addr <= 0x03ffffff) {
		jump->flags |= PATCH_B | PATCH_ABS_B | extra_jump_flags;
		return 1;
	}

#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
#if (defined SLJIT_PASS_ENTRY_ADDR_TO_CALL && SLJIT_PASS_ENTRY_ADDR_TO_CALL)
keep_address:
#endif
	if (target_addr <= 0x7fffffff) {
		jump->flags |= PATCH_ABS32;
		return 1;
	}

	if (target_addr <= 0x7fffffffffffl) {
		jump->flags |= PATCH_ABS48;
		return 1;
	}
#endif

	return 0;
}

#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)

static SLJIT_INLINE sljit_sw put_label_get_length(struct sljit_put_label *put_label, sljit_uw max_label)
{
	if (max_label < 0x100000000l) {
		put_label->flags = 0;
		return 1;
	}

	if (max_label < 0x1000000000000l) {
		put_label->flags = 1;
		return 3;
	}

	put_label->flags = 2;
	return 4;
}

static SLJIT_INLINE void put_label_set(struct sljit_put_label *put_label)
{
	sljit_uw addr = put_label->label->addr;
	sljit_ins *inst = (sljit_ins *)put_label->addr;
	sljit_s32 reg = *inst;

	if (put_label->flags == 0) {
		SLJIT_ASSERT(addr < 0x100000000l);
		inst[0] = ORIS | S(TMP_ZERO) | A(reg) | IMM(addr >> 16);
	}
	else {
		if (put_label->flags == 1) {
			SLJIT_ASSERT(addr < 0x1000000000000l);
			inst[0] = ORI | S(TMP_ZERO) | A(reg) | IMM(addr >> 32);
		}
		else {
			inst[0] = ORIS | S(TMP_ZERO) | A(reg) | IMM(addr >> 48);
			inst[1] = ORI | S(reg) | A(reg) | IMM((addr >> 32) & 0xffff);
			inst ++;
		}

		inst[1] = RLDI(reg, reg, 32, 31, 1);
		inst[2] = ORIS | S(reg) | A(reg) | IMM((addr >> 16) & 0xffff);
		inst += 2;
	}

	inst[1] = ORI | S(reg) | A(reg) | IMM(addr & 0xffff);
}

#endif

SLJIT_API_FUNC_ATTRIBUTE void* sljit_generate_code(struct sljit_compiler *compiler)
{
	struct sljit_memory_fragment *buf;
	sljit_ins *code;
	sljit_ins *code_ptr;
	sljit_ins *buf_ptr;
	sljit_ins *buf_end;
	sljit_uw word_count;
	sljit_uw next_addr;
	sljit_sw executable_offset;
	sljit_uw addr;

	struct sljit_label *label;
	struct sljit_jump *jump;
	struct sljit_const *const_;
	struct sljit_put_label *put_label;

	CHECK_ERROR_PTR();
	CHECK_PTR(check_sljit_generate_code(compiler));
	reverse_buf(compiler);

#if (defined SLJIT_INDIRECT_CALL && SLJIT_INDIRECT_CALL)
#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	compiler->size += (compiler->size & 0x1) + (sizeof(struct sljit_function_context) / sizeof(sljit_ins));
#else
	compiler->size += (sizeof(struct sljit_function_context) / sizeof(sljit_ins));
#endif
#endif
	code = (sljit_ins*)SLJIT_MALLOC_EXEC(compiler->size * sizeof(sljit_ins), compiler->exec_allocator_data);
	PTR_FAIL_WITH_EXEC_IF(code);
	buf = compiler->buf;

	code_ptr = code;
	word_count = 0;
	next_addr = 0;
	executable_offset = SLJIT_EXEC_OFFSET(code);

	label = compiler->labels;
	jump = compiler->jumps;
	const_ = compiler->consts;
	put_label = compiler->put_labels;

	do {
		buf_ptr = (sljit_ins*)buf->memory;
		buf_end = buf_ptr + (buf->used_size >> 2);
		do {
			*code_ptr = *buf_ptr++;
			if (next_addr == word_count) {
				SLJIT_ASSERT(!label || label->size >= word_count);
				SLJIT_ASSERT(!jump || jump->addr >= word_count);
				SLJIT_ASSERT(!const_ || const_->addr >= word_count);
				SLJIT_ASSERT(!put_label || put_label->addr >= word_count);

				/* These structures are ordered by their address. */
				if (label && label->size == word_count) {
					/* Just recording the address. */
					label->addr = (sljit_uw)SLJIT_ADD_EXEC_OFFSET(code_ptr, executable_offset);
					label->size = code_ptr - code;
					label = label->next;
				}
				if (jump && jump->addr == word_count) {
#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
					jump->addr = (sljit_uw)(code_ptr - 3);
#else
					jump->addr = (sljit_uw)(code_ptr - 6);
#endif
					if (detect_jump_type(jump, code_ptr, code, executable_offset)) {
#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
						code_ptr[-3] = code_ptr[0];
						code_ptr -= 3;
#else
						if (jump->flags & PATCH_ABS32) {
							code_ptr -= 3;
							code_ptr[-1] = code_ptr[2];
							code_ptr[0] = code_ptr[3];
						}
						else if (jump->flags & PATCH_ABS48) {
							code_ptr--;
							code_ptr[-1] = code_ptr[0];
							code_ptr[0] = code_ptr[1];
							/* rldicr rX,rX,32,31 -> rX,rX,16,47 */
							SLJIT_ASSERT((code_ptr[-3] & 0xfc00ffff) == 0x780007c6);
							code_ptr[-3] ^= 0x8422;
							/* oris -> ori */
							code_ptr[-2] ^= 0x4000000;
						}
						else {
							code_ptr[-6] = code_ptr[0];
							code_ptr -= 6;
						}
#endif
						if (jump->flags & REMOVE_COND) {
							code_ptr[0] = BCx | (2 << 2) | ((code_ptr[0] ^ (8 << 21)) & 0x03ff0001);
							code_ptr++;
							jump->addr += sizeof(sljit_ins);
							code_ptr[0] = Bx;
							jump->flags -= IS_COND;
						}
					}
					jump = jump->next;
				}
				if (const_ && const_->addr == word_count) {
					const_->addr = (sljit_uw)code_ptr;
					const_ = const_->next;
				}
				if (put_label && put_label->addr == word_count) {
					SLJIT_ASSERT(put_label->label);
					put_label->addr = (sljit_uw)code_ptr;
#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
					code_ptr += put_label_get_length(put_label, (sljit_uw)(SLJIT_ADD_EXEC_OFFSET(code, executable_offset) + put_label->label->size));
					word_count += 4;
#endif
					put_label = put_label->next;
				}
				next_addr = compute_next_addr(label, jump, const_, put_label);
			}
			code_ptr ++;
			word_count ++;
		} while (buf_ptr < buf_end);

		buf = buf->next;
	} while (buf);

	if (label && label->size == word_count) {
		label->addr = (sljit_uw)SLJIT_ADD_EXEC_OFFSET(code_ptr, executable_offset);
		label->size = code_ptr - code;
		label = label->next;
	}

	SLJIT_ASSERT(!label);
	SLJIT_ASSERT(!jump);
	SLJIT_ASSERT(!const_);
	SLJIT_ASSERT(!put_label);

#if (defined SLJIT_INDIRECT_CALL && SLJIT_INDIRECT_CALL)
	SLJIT_ASSERT(code_ptr - code <= (sljit_sw)compiler->size - (sizeof(struct sljit_function_context) / sizeof(sljit_ins)));
#else
	SLJIT_ASSERT(code_ptr - code <= (sljit_sw)compiler->size);
#endif

	jump = compiler->jumps;
	while (jump) {
		do {
			addr = (jump->flags & JUMP_LABEL) ? jump->u.label->addr : jump->u.target;
			buf_ptr = (sljit_ins *)jump->addr;

			if (jump->flags & PATCH_B) {
				if (jump->flags & IS_COND) {
					if (!(jump->flags & PATCH_ABS_B)) {
						addr -= (sljit_uw)SLJIT_ADD_EXEC_OFFSET(buf_ptr, executable_offset);
						SLJIT_ASSERT((sljit_sw)addr <= 0x7fff && (sljit_sw)addr >= -0x8000);
						*buf_ptr = BCx | (addr & 0xfffc) | ((*buf_ptr) & 0x03ff0001);
					}
					else {
						SLJIT_ASSERT(addr <= 0xffff);
						*buf_ptr = BCx | (addr & 0xfffc) | 0x2 | ((*buf_ptr) & 0x03ff0001);
					}
				}
				else {
					if (!(jump->flags & PATCH_ABS_B)) {
						addr -= (sljit_uw)SLJIT_ADD_EXEC_OFFSET(buf_ptr, executable_offset);
						SLJIT_ASSERT((sljit_sw)addr <= 0x01ffffff && (sljit_sw)addr >= -0x02000000);
						*buf_ptr = Bx | (addr & 0x03fffffc) | ((*buf_ptr) & 0x1);
					}
					else {
						SLJIT_ASSERT(addr <= 0x03ffffff);
						*buf_ptr = Bx | (addr & 0x03fffffc) | 0x2 | ((*buf_ptr) & 0x1);
					}
				}
				break;
			}

			/* Set the fields of immediate loads. */
#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
			buf_ptr[0] = (buf_ptr[0] & 0xffff0000) | ((addr >> 16) & 0xffff);
			buf_ptr[1] = (buf_ptr[1] & 0xffff0000) | (addr & 0xffff);
#else
			if (jump->flags & PATCH_ABS32) {
				SLJIT_ASSERT(addr <= 0x7fffffff);
				buf_ptr[0] = (buf_ptr[0] & 0xffff0000) | ((addr >> 16) & 0xffff);
				buf_ptr[1] = (buf_ptr[1] & 0xffff0000) | (addr & 0xffff);
				break;
			}
			if (jump->flags & PATCH_ABS48) {
				SLJIT_ASSERT(addr <= 0x7fffffffffff);
				buf_ptr[0] = (buf_ptr[0] & 0xffff0000) | ((addr >> 32) & 0xffff);
				buf_ptr[1] = (buf_ptr[1] & 0xffff0000) | ((addr >> 16) & 0xffff);
				buf_ptr[3] = (buf_ptr[3] & 0xffff0000) | (addr & 0xffff);
				break;
			}
			buf_ptr[0] = (buf_ptr[0] & 0xffff0000) | ((addr >> 48) & 0xffff);
			buf_ptr[1] = (buf_ptr[1] & 0xffff0000) | ((addr >> 32) & 0xffff);
			buf_ptr[3] = (buf_ptr[3] & 0xffff0000) | ((addr >> 16) & 0xffff);
			buf_ptr[4] = (buf_ptr[4] & 0xffff0000) | (addr & 0xffff);
#endif
		} while (0);
		jump = jump->next;
	}

	put_label = compiler->put_labels;
	while (put_label) {
#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
		addr = put_label->label->addr;
		buf_ptr = (sljit_ins *)put_label->addr;

		SLJIT_ASSERT((buf_ptr[0] & 0xfc1f0000) == ADDIS && (buf_ptr[1] & 0xfc000000) == ORI);
		buf_ptr[0] |= (addr >> 16) & 0xffff;
		buf_ptr[1] |= addr & 0xffff;
#else
		put_label_set(put_label);
#endif
		put_label = put_label->next;
	}

	compiler->error = SLJIT_ERR_COMPILED;
	compiler->executable_offset = executable_offset;
	compiler->executable_size = (code_ptr - code) * sizeof(sljit_ins);

	code = (sljit_ins *)SLJIT_ADD_EXEC_OFFSET(code, executable_offset);

#if (defined SLJIT_INDIRECT_CALL && SLJIT_INDIRECT_CALL)
#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (((sljit_sw)code_ptr) & 0x4)
		code_ptr++;
#endif
	sljit_set_function_context(NULL, (struct sljit_function_context*)code_ptr, (sljit_sw)code, (void*)sljit_generate_code);
#endif

	code_ptr = (sljit_ins *)SLJIT_ADD_EXEC_OFFSET(code_ptr, executable_offset);

	SLJIT_CACHE_FLUSH(code, code_ptr);
	SLJIT_UPDATE_WX_FLAGS(code, code_ptr, 1);

#if (defined SLJIT_INDIRECT_CALL && SLJIT_INDIRECT_CALL)
	return code_ptr;
#else
	return code;
#endif
}

SLJIT_API_FUNC_ATTRIBUTE sljit_s32 sljit_has_cpu_feature(sljit_s32 feature_type)
{
	switch (feature_type) {
	case SLJIT_HAS_FPU:
#ifdef SLJIT_IS_FPU_AVAILABLE
		return SLJIT_IS_FPU_AVAILABLE;
#else
		/* Available by default. */
		return 1;
#endif

	/* A saved register is set to a zero value. */
	case SLJIT_HAS_ZERO_REGISTER:
	case SLJIT_HAS_CLZ:
	case SLJIT_HAS_PREFETCH:
		return 1;

	default:
		return 0;
	}
}

/* --------------------------------------------------------------------- */
/*  Entry, exit                                                          */
/* --------------------------------------------------------------------- */

/* inp_flags: */

/* Creates an index in data_transfer_insts array. */
#define LOAD_DATA	0x01
#define INDEXED		0x02
#define SIGNED_DATA	0x04

#define WORD_DATA	0x00
#define BYTE_DATA	0x08
#define HALF_DATA	0x10
#define INT_DATA	0x18
/* Separates integer and floating point registers */
#define GPR_REG		0x1f
#define DOUBLE_DATA	0x20

#define MEM_MASK	0x7f

/* Other inp_flags. */

/* Integer opertion and set flags -> requires exts on 64 bit systems. */
#define ALT_SIGN_EXT	0x000100
/* This flag affects the RC() and OERC() macros. */
#define ALT_SET_FLAGS	0x000400
#define ALT_FORM1	0x001000
#define ALT_FORM2	0x002000
#define ALT_FORM3	0x004000
#define ALT_FORM4	0x008000
#define ALT_FORM5	0x010000

/* Source and destination is register. */
#define REG_DEST	0x000001
#define REG1_SOURCE	0x000002
#define REG2_SOURCE	0x000004
/*
ALT_SIGN_EXT		0x000100
ALT_SET_FLAGS		0x000200
ALT_FORM1		0x001000
...
ALT_FORM5		0x010000 */

#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
#include "sljitNativePPC_32.c"
#else
#include "sljitNativePPC_64.c"
#endif

#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
#define STACK_STORE	STW
#define STACK_LOAD	LWZ
#else
#define STACK_STORE	STD
#define STACK_LOAD	LD
#endif

SLJIT_API_FUNC_ATTRIBUTE sljit_s32 sljit_emit_enter(struct sljit_compiler *compiler,
	sljit_s32 options, sljit_s32 arg_types, sljit_s32 scratches, sljit_s32 saveds,
	sljit_s32 fscratches, sljit_s32 fsaveds, sljit_s32 local_size)
{
	sljit_s32 args, i, tmp, offs;

	CHECK_ERROR();
	CHECK(check_sljit_emit_enter(compiler, options, arg_types, scratches, saveds, fscratches, fsaveds, local_size));
	set_emit_enter(compiler, options, arg_types, scratches, saveds, fscratches, fsaveds, local_size);

	FAIL_IF(push_inst(compiler, MFLR | D(0)));
	offs = -(sljit_s32)(sizeof(sljit_sw));
	FAIL_IF(push_inst(compiler, STACK_STORE | S(TMP_ZERO) | A(SLJIT_SP) | IMM(offs)));

	tmp = saveds < SLJIT_NUMBER_OF_SAVED_REGISTERS ? (SLJIT_S0 + 1 - saveds) : SLJIT_FIRST_SAVED_REG;
	for (i = SLJIT_S0; i >= tmp; i--) {
		offs -= (sljit_s32)(sizeof(sljit_sw));
		FAIL_IF(push_inst(compiler, STACK_STORE | S(i) | A(SLJIT_SP) | IMM(offs)));
	}

	for (i = scratches; i >= SLJIT_FIRST_SAVED_REG; i--) {
		offs -= (sljit_s32)(sizeof(sljit_sw));
		FAIL_IF(push_inst(compiler, STACK_STORE | S(i) | A(SLJIT_SP) | IMM(offs)));
	}

	SLJIT_ASSERT(offs == -(sljit_s32)GET_SAVED_REGISTERS_SIZE(compiler->scratches, compiler->saveds, 1));

#if (defined SLJIT_PPC_STACK_FRAME_V2 && SLJIT_PPC_STACK_FRAME_V2)
	FAIL_IF(push_inst(compiler, STACK_STORE | S(0) | A(SLJIT_SP) | IMM(2 * sizeof(sljit_sw))));
#else
	FAIL_IF(push_inst(compiler, STACK_STORE | S(0) | A(SLJIT_SP) | IMM(sizeof(sljit_sw))));
#endif

	FAIL_IF(push_inst(compiler, ADDI | D(TMP_ZERO) | A(0) | 0));

	args = get_arg_count(arg_types);

	if (args >= 1)
		FAIL_IF(push_inst(compiler, OR | S(SLJIT_R0) | A(SLJIT_S0) | B(SLJIT_R0)));
	if (args >= 2)
		FAIL_IF(push_inst(compiler, OR | S(SLJIT_R1) | A(SLJIT_S1) | B(SLJIT_R1)));
	if (args >= 3)
		FAIL_IF(push_inst(compiler, OR | S(SLJIT_R2) | A(SLJIT_S2) | B(SLJIT_R2)));

	local_size += GET_SAVED_REGISTERS_SIZE(scratches, saveds, 1) + SLJIT_LOCALS_OFFSET;
	local_size = (local_size + 15) & ~0xf;
	compiler->local_size = local_size;

#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
	if (local_size <= SIMM_MAX)
		FAIL_IF(push_inst(compiler, STWU | S(SLJIT_SP) | A(SLJIT_SP) | IMM(-local_size)));
	else {
		FAIL_IF(load_immediate(compiler, 0, -local_size));
		FAIL_IF(push_inst(compiler, STWUX | S(SLJIT_SP) | A(SLJIT_SP) | B(0)));
	}
#else
	if (local_size <= SIMM_MAX)
		FAIL_IF(push_inst(compiler, STDU | S(SLJIT_SP) | A(SLJIT_SP) | IMM(-local_size)));
	else {
		FAIL_IF(load_immediate(compiler, 0, -local_size));
		FAIL_IF(push_inst(compiler, STDUX | S(SLJIT_SP) | A(SLJIT_SP) | B(0)));
	}
#endif

	return SLJIT_SUCCESS;
}

SLJIT_API_FUNC_ATTRIBUTE sljit_s32 sljit_set_context(struct sljit_compiler *compiler,
	sljit_s32 options, sljit_s32 arg_types, sljit_s32 scratches, sljit_s32 saveds,
	sljit_s32 fscratches, sljit_s32 fsaveds, sljit_s32 local_size)
{
	CHECK_ERROR();
	CHECK(check_sljit_set_context(compiler, options, arg_types, scratches, saveds, fscratches, fsaveds, local_size));
	set_set_context(compiler, options, arg_types, scratches, saveds, fscratches, fsaveds, local_size);

	local_size += GET_SAVED_REGISTERS_SIZE(scratches, saveds, 1) + SLJIT_LOCALS_OFFSET;
	compiler->local_size = (local_size + 15) & ~0xf;
	return SLJIT_SUCCESS;
}

SLJIT_API_FUNC_ATTRIBUTE sljit_s32 sljit_emit_return(struct sljit_compiler *compiler, sljit_s32 op, sljit_s32 src, sljit_sw srcw)
{
	sljit_s32 i, tmp, offs;

	CHECK_ERROR();
	CHECK(check_sljit_emit_return(compiler, op, src, srcw));

	FAIL_IF(emit_mov_before_return(compiler, op, src, srcw));

	if (compiler->local_size <= SIMM_MAX)
		FAIL_IF(push_inst(compiler, ADDI | D(SLJIT_SP) | A(SLJIT_SP) | IMM(compiler->local_size)));
	else {
		FAIL_IF(load_immediate(compiler, 0, compiler->local_size));
		FAIL_IF(push_inst(compiler, ADD | D(SLJIT_SP) | A(SLJIT_SP) | B(0)));
	}

#if (defined SLJIT_PPC_STACK_FRAME_V2 && SLJIT_PPC_STACK_FRAME_V2)
	FAIL_IF(push_inst(compiler, STACK_LOAD | D(0) | A(SLJIT_SP) | IMM(2 * sizeof(sljit_sw))));
#else
	FAIL_IF(push_inst(compiler, STACK_LOAD | D(0) | A(SLJIT_SP) | IMM(sizeof(sljit_sw))));
#endif

	offs = -(sljit_s32)GET_SAVED_REGISTERS_SIZE(compiler->scratches, compiler->saveds, 1);

	tmp = compiler->scratches;
	for (i = SLJIT_FIRST_SAVED_REG; i <= tmp; i++) {
		FAIL_IF(push_inst(compiler, STACK_LOAD | D(i) | A(SLJIT_SP) | IMM(offs)));
		offs += (sljit_s32)(sizeof(sljit_sw));
	}

	tmp = compiler->saveds < SLJIT_NUMBER_OF_SAVED_REGISTERS ? (SLJIT_S0 + 1 - compiler->saveds) : SLJIT_FIRST_SAVED_REG;
	for (i = tmp; i <= SLJIT_S0; i++) {
		FAIL_IF(push_inst(compiler, STACK_LOAD | D(i) | A(SLJIT_SP) | IMM(offs)));
		offs += (sljit_s32)(sizeof(sljit_sw));
	}

	FAIL_IF(push_inst(compiler, STACK_LOAD | D(TMP_ZERO) | A(SLJIT_SP) | IMM(offs)));
	SLJIT_ASSERT(offs == -(sljit_sw)(sizeof(sljit_sw)));

	FAIL_IF(push_inst(compiler, MTLR | S(0)));
	FAIL_IF(push_inst(compiler, BLR));

	return SLJIT_SUCCESS;
}

#undef STACK_STORE
#undef STACK_LOAD

/* --------------------------------------------------------------------- */
/*  Operators                                                            */
/* --------------------------------------------------------------------- */

/* s/l - store/load (1 bit)
   i/x - immediate/indexed form
   u/s - signed/unsigned (1 bit)
   w/b/h/i - word/byte/half/int allowed (2 bit)

   Some opcodes are repeated (e.g. store signed / unsigned byte is the same instruction). */

/* 64 bit only: [reg+imm] must be aligned to 4 bytes. */
#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
#define INT_ALIGNED	0x10000
#endif

#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
#define ARCH_32_64(a, b)	a
#define INST_CODE_AND_DST(inst, flags, reg) \
	((inst) | (((flags) & MEM_MASK) <= GPR_REG ? D(reg) : FD(reg)))
#else
#define ARCH_32_64(a, b)	b
#define INST_CODE_AND_DST(inst, flags, reg) \
	(((inst) & ~INT_ALIGNED) | (((flags) & MEM_MASK) <= GPR_REG ? D(reg) : FD(reg)))
#endif

static const sljit_ins data_transfer_insts[64 + 16] = {

/* -------- Integer -------- */

/* Word. */

/* w u i s */ ARCH_32_64(HI(36) /* stw */, HI(62) | INT_ALIGNED | 0x0 /* std */),
/* w u i l */ ARCH_32_64(HI(32) /* lwz */, HI(58) | INT_ALIGNED | 0x0 /* ld */),
/* w u x s */ ARCH_32_64(HI(31) | LO(151) /* stwx */, HI(31) | LO(149) /* stdx */),
/* w u x l */ ARCH_32_64(HI(31) | LO(23) /* lwzx */, HI(31) | LO(21) /* ldx */),

/* w s i s */ ARCH_32_64(HI(36) /* stw */, HI(62) | INT_ALIGNED | 0x0 /* std */),
/* w s i l */ ARCH_32_64(HI(32) /* lwz */, HI(58) | INT_ALIGNED | 0x0 /* ld */),
/* w s x s */ ARCH_32_64(HI(31) | LO(151) /* stwx */, HI(31) | LO(149) /* stdx */),
/* w s x l */ ARCH_32_64(HI(31) | LO(23) /* lwzx */, HI(31) | LO(21) /* ldx */),

/* Byte. */

/* b u i s */ HI(38) /* stb */,
/* b u i l */ HI(34) /* lbz */,
/* b u x s */ HI(31) | LO(215) /* stbx */,
/* b u x l */ HI(31) | LO(87) /* lbzx */,

/* b s i s */ HI(38) /* stb */,
/* b s i l */ HI(34) /* lbz */ /* EXTS_REQ */,
/* b s x s */ HI(31) | LO(215) /* stbx */,
/* b s x l */ HI(31) | LO(87) /* lbzx */ /* EXTS_REQ */,

/* Half. */

/* h u i s */ HI(44) /* sth */,
/* h u i l */ HI(40) /* lhz */,
/* h u x s */ HI(31) | LO(407) /* sthx */,
/* h u x l */ HI(31) | LO(279) /* lhzx */,

/* h s i s */ HI(44) /* sth */,
/* h s i l */ HI(42) /* lha */,
/* h s x s */ HI(31) | LO(407) /* sthx */,
/* h s x l */ HI(31) | LO(343) /* lhax */,

/* Int. */

/* i u i s */ HI(36) /* stw */,
/* i u i l */ HI(32) /* lwz */,
/* i u x s */ HI(31) | LO(151) /* stwx */,
/* i u x l */ HI(31) | LO(23) /* lwzx */,

/* i s i s */ HI(36) /* stw */,
/* i s i l */ ARCH_32_64(HI(32) /* lwz */, HI(58) | INT_ALIGNED | 0x2 /* lwa */),
/* i s x s */ HI(31) | LO(151) /* stwx */,
/* i s x l */ ARCH_32_64(HI(31) | LO(23) /* lwzx */, HI(31) | LO(341) /* lwax */),

/* -------- Floating point -------- */

/* d   i s */ HI(54) /* stfd */,
/* d   i l */ HI(50) /* lfd */,
/* d   x s */ HI(31) | LO(727) /* stfdx */,
/* d   x l */ HI(31) | LO(599) /* lfdx */,

/* s   i s */ HI(52) /* stfs */,
/* s   i l */ HI(48) /* lfs */,
/* s   x s */ HI(31) | LO(663) /* stfsx */,
/* s   x l */ HI(31) | LO(535) /* lfsx */,
};

static const sljit_ins updated_data_transfer_insts[64] = {

/* -------- Integer -------- */

/* Word. */

/* w u i s */ ARCH_32_64(HI(37) /* stwu */, HI(62) | INT_ALIGNED | 0x1 /* stdu */),
/* w u i l */ ARCH_32_64(HI(33) /* lwzu */, HI(58) | INT_ALIGNED | 0x1 /* ldu */),
/* w u x s */ ARCH_32_64(HI(31) | LO(183) /* stwux */, HI(31) | LO(181) /* stdux */),
/* w u x l */ ARCH_32_64(HI(31) | LO(55) /* lwzux */, HI(31) | LO(53) /* ldux */),

/* w s i s */ ARCH_32_64(HI(37) /* stwu */, HI(62) | INT_ALIGNED | 0x1 /* stdu */),
/* w s i l */ ARCH_32_64(HI(33) /* lwzu */, HI(58) | INT_ALIGNED | 0x1 /* ldu */),
/* w s x s */ ARCH_32_64(HI(31) | LO(183) /* stwux */, HI(31) | LO(181) /* stdux */),
/* w s x l */ ARCH_32_64(HI(31) | LO(55) /* lwzux */, HI(31) | LO(53) /* ldux */),

/* Byte. */

/* b u i s */ HI(39) /* stbu */,
/* b u i l */ HI(35) /* lbzu */,
/* b u x s */ HI(31) | LO(247) /* stbux */,
/* b u x l */ HI(31) | LO(119) /* lbzux */,

/* b s i s */ HI(39) /* stbu */,
/* b s i l */ 0 /* no such instruction */,
/* b s x s */ HI(31) | LO(247) /* stbux */,
/* b s x l */ 0 /* no such instruction */,

/* Half. */

/* h u i s */ HI(45) /* sthu */,
/* h u i l */ HI(41) /* lhzu */,
/* h u x s */ HI(31) | LO(439) /* sthux */,
/* h u x l */ HI(31) | LO(311) /* lhzux */,

/* h s i s */ HI(45) /* sthu */,
/* h s i l */ HI(43) /* lhau */,
/* h s x s */ HI(31) | LO(439) /* sthux */,
/* h s x l */ HI(31) | LO(375) /* lhaux */,

/* Int. */

/* i u i s */ HI(37) /* stwu */,
/* i u i l */ HI(33) /* lwzu */,
/* i u x s */ HI(31) | LO(183) /* stwux */,
/* i u x l */ HI(31) | LO(55) /* lwzux */,

/* i s i s */ HI(37) /* stwu */,
/* i s i l */ ARCH_32_64(HI(33) /* lwzu */, 0 /* no such instruction */),
/* i s x s */ HI(31) | LO(183) /* stwux */,
/* i s x l */ ARCH_32_64(HI(31) | LO(55) /* lwzux */, HI(31) | LO(373) /* lwaux */),

/* -------- Floating point -------- */

/* d   i s */ HI(55) /* stfdu */,
/* d   i l */ HI(51) /* lfdu */,
/* d   x s */ HI(31) | LO(759) /* stfdux */,
/* d   x l */ HI(31) | LO(631) /* lfdux */,

/* s   i s */ HI(53) /* stfsu */,
/* s   i l */ HI(49) /* lfsu */,
/* s   x s */ HI(31) | LO(695) /* stfsux */,
/* s   x l */ HI(31) | LO(567) /* lfsux */,
};

#undef ARCH_32_64

/* Simple cases, (no caching is required). */
static sljit_s32 emit_op_mem(struct sljit_compiler *compiler, sljit_s32 inp_flags, sljit_s32 reg,
	sljit_s32 arg, sljit_sw argw, sljit_s32 tmp_reg)
{
	sljit_ins inst;
	sljit_s32 offs_reg;
	sljit_sw high_short;

	/* Should work when (arg & REG_MASK) == 0. */
	SLJIT_ASSERT(A(0) == 0);
	SLJIT_ASSERT(arg & SLJIT_MEM);

	if (SLJIT_UNLIKELY(arg & OFFS_REG_MASK)) {
		argw &= 0x3;
		offs_reg = OFFS_REG(arg);

		if (argw != 0) {
#if (defined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
			FAIL_IF(push_inst(compiler, RLWINM | S(OFFS_REG(arg)) | A(tmp_reg) | (argw << 11) | ((31 - argw) << 1)));
#else
			FAIL_IF(push_inst(compiler, RLDI(tmp_reg, OFFS_REG(arg), argw, 63 - argw, 1)));
#endif
			offs_reg = tmp_reg;
		}

		inst = data_transfer_insts[(inp_flags | INDEXED) & MEM_MASK];

#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(!(inst & INT_ALIGNED));
#endif

		return push_inst(compiler, INST_CODE_AND_DST(inst, inp_flags, reg) | A(arg & REG_MASK) | B(offs_reg));
	}

	inst = data_transfer_insts[inp_flags & MEM_MASK];
	arg &= REG_MASK;

#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if ((inst & INT_ALIGNED) && (argw & 0x3) != 0) {
		FAIL_IF(load_immediate(compiler, tmp_reg, argw));

		inst = data_transfer_insts[(inp_flags | INDEXED) & MEM_MASK];
		return push_inst(compiler, INST_CODE_AND_DST(inst, inp_flags, reg) | A(arg) | B(tmp_reg));
	}
#endif

	if (argw <= SIMM_MAX && argw >= SIMM_MIN)
		return push_inst(compiler, INST_CODE_AND_DST(inst, inp_flags, reg) | A(arg) | IMM(argw));

#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x7fff7fffl && argw >= -0x80000000l) {
#endif

		high_short = (sljit_s32)(argw + ((argw & 0x8000) << 1)) & ~0xffff;

#if (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(high_short && high_short <= 0x7fffffffl && high_short >= -0x80000000l);
#else
		SLJIT_ASSERT(high_short);
#endif

		FAIL_IF(push_inst(compiler, ADDIS | D(tmp_reg) | A(arg) | IMM(ndif

		FAILIT_ASreg) | A(arg) | IMM(st(compiler, INST_CODE_AND_DST(inst, inp_flags, reg) | A(arg) | IMM(argrg) | IMM(nif (defined SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x}ork whThg. ssndif
rgw-NFI] mu s */ immediate(compiler, tmp_reg, argw));

		inst = data_tansfer_insts[(inp_flags | INDEXED) & MEM_MASK];
		return push_ist(compiler, INST_CODE_AND_DST(inst, inp_flags, reg) | A(arg) | B(tmp_reg));
	}
#endif

	ifT_API_FUNC32 emit_op_mem(struct slcompiler *compiler, sljit_s32 op, sljit_s32 src, sljit_sw ) |ut A(arg)fs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrc1w)
{
	sljit_s31w)fs_reg;
	sljsrc2w)
{
	sljit_s322 i, t wheg)1 goes/
#iT_NUMBER ort_s3 | B
	1) eg)2 goes/
#iT_NUMBE2w)ile ort_s3 | B
	1)  ssult goes/
#iT_NUMBE2w)soxt;
  ssult can
#eliT_NUMBERSERT(A_reg;
	sljmb,_ *)ST_NUMBE2;fs_reg;
	sljsrc1_r;fs_reg;
	sljsrc2_r;fs_reg;
	sljsugg_src2_r*)ST_NUMBE2;fs_reg;
	sljturn 4;
) |ut A(argITAB01000
...tmp_000
#deftmp_000
#de3tmp_000
#de4tmp_000
#de5tmp_0000100
ALTtmp_00000)
#definwork whDregister. *it_reSERT(AKELY(aOWBLE;, 63 << addr = b,_ *)Sd offs	_ABS48;
	001
#def!= 0) {
#opT_SAVED_REMOVIG_PopT<SAVED_REMOV_
#end	sugg_src2_r*)S b,_ ;0x}ork whtinatio1SERT(AKELYFASTBLE;, 63src1 addr =src1_ri >=rc1ffs	_ABS48;
	001002
#def;if (put_laKELY=rc1

	if (SLif load_immediate(compiler, tmp_reg, argw)T_NUMBER,t_s31w| IMM(src1_ri >T_NUMBER;if (put_label-ov_before_retsljit_creg, argw)) |ut A(argI|1
#define w)T_NUMBER,t_s31,t_s31ww)T_NUMBER| IMM(src1_ri >T_NUMBER;if (rk whtinatio2SERT(AKELYFASTBLE;, 63src2 addr =src2_ri >=rc2ffs	_ABS48;
	001202
#def;i
flags & _COND) {
	1
#def)IG_PopT_SAVED_REMOVIG_PopT<SAVED_REMOV_
#end	 b,_ *)Ssrc2_r;fs (put_laKELY=rc2

	if (SLif load_immediate(compiler, tmp_reg, argw)sugg_src2_r,t_s322  IMM(src2_ri >=ugg_src2_r;if (put_label-ov_before_retsljit_creg, argw)) |ut A(argI|1
#define w)sugg_src2_r,t_s32,t_s322w)T_NUMBE2  IMM(src2_ri >=ugg_src2_r;if (_mov_before_retsd).SLJIp src, srcw));

A(arg)  b,_ ,jsrc1_r,Ssrc2_riler->loca!3 <<

	if (SLJIT_h_inst(comp
}

#undef STAC_ist(compe_retsljit_creg, argw)) |ut A(arg)  b,_ ,jmb, tmb,w))T_NUMBER|_FUNC_ATTRIBUTE sljit_s32 sljit_emit_return(struct op0compiler *compiler, sljit_s32 op, sljit_s32 sr i, LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x sljit_sw ) t opi >opi
	if (SLi32_OPIL_IF(push_
	CHECK(check_sljit_emit_return(compileop0csrc, srcw));iler->opi >STEROPnst,#opntext_type) opT_HAS_FPU:
#ifdeBREAKPO& (HAS_PREFETCH:
NOP:MM(st(compiler, INST_CODE_AND_NOPntex_PREFETCH:
LMUL_UW:ex_PREFETCH:
LMUL_SW:exinst(compiler, OR | S(SLJIT_R0) | A(SLJIT_S0) | B(T_NUMBER| );
	if (args >= 2LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(hnst(compiler, MTLR | S(0)));
| LO | A(SLJIT_S0) | B(T_NUMBER| );
	if (arg1 | IMM(st(compiler, INST_CODE_AND_#opT==FETCH:
LMUL_UW ?1) | LO :1) | L) | A(SLJIT_S1) | B(T_NUMBER| );
	if (arg1 |T_ASSERT(hnst(compiler, MTLR | S(0)));
| LW | A(SLJIT_S0) | B(T_NUMBER| );
	if (arg1 | IMM(st(compiler, INST_CODE_AND_#opT==FETCH:
LMUL_UW ?1) | WO :1) | W) | A(SLJIT_S1) | B(T_NUMBER| );
	if (arg1 |T_ASsljit_iPREFETCH:
DIVMOD_UW:ex_PREFETCH:
DIVMOD_SW:exinst(compiler, OR | S(SLJIT_R0) | A(SLJIT_S0) | B(T_NUMBER| );
	if (args >= 2LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(hnst(compiler, MTLR | S(0)));() t opi?_#opT==FETCH:
DIVMOD_UW(reg| LO :1g| L#end#opT==FETCH:
DIVMOD_UW(reg| DO :1g| D)) | A(SLJIT_S0) | B(SLJIT_S0) | 
	if (arg1 | IMM(nst(compiler, MTLR | S(0)));() t opi?_
| LW :;
| LO) | A(SLJIT_S1) | B(SLJIT_S0) | 
	if (arg1 | IMASSERT(hnst(compiler, MTLR | S(0)));#opT==FETCH:
DIVMOD_UW(reg| LO :1g| L#e| A(SLJIT_S0) | B(SLJIT_S0) | 
	if (arg1 | IMM(nst(compiler, MTLR | S(0)));
| LW | A(SLJIT_S1) | B(SLJIT_S0) | 
	if (arg1 | IMASeg = tmst(compiler, INST_CODE_AND_)
#d | A(SLJIT_S1) | B(SLJIT_SR| );
	T_NUMBER| IMM_PREFETCH:
DIV_UW:ex_PREFETCH:
DIV_SW:eLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(hst(compiler, INST_CODE_AND_#) t opi?_#opT==FETCH:
DIV_UW(reg| LO :1g| L#end#opT==FETCH:
DIV_UW(reg| DO :1g| D)) | A(SLJIT_S0) | B(SLJIT_S0) | 
	if (arg1 |IMASSERT(hst(compiler, INST_CODE_AND_#opT==FETCH:
DIV_UW(reg| LO :1g| L#e| A(SLJIT_S0) | B(SLJIT_S0) | 
	if (arg1 |IMASsljit_iPREFETCH:
ENDB_HAS_CLZ:
	caseSKIPIL_IF(S_BE
#dEUMBTURN:_inst(comp
}

#undef STACf (_mUCCESS;
}

static SLJIT_INLINE s_op_mem(struct prefeypecompiler *compiler,
	sljit_s32 opt-------- sljit_sw srcw)
{
	sljit_s32 i, tloca!3_s3 K)) {
		argw &= 0x3;
	KELY=rcw_ASSEaddr >s3 K)offs_reg))!=FETCH:
UNUSED#end	st(compiler, INST_CODE_AND_| LO 
	args = B >s3 K)offs_reg)ata_trmmediate(compiler, tmp_reg, argw)T_NUMBER,t_s32  IMM(* w u ks _tyh	if (SLJIT0()ching as _ell1;
#endif

	/*iler, INST_CODE_AND_| LO 
	ar>s3 K)offs_reg)));
	T_NUMBER| IMM (_m=rcw__reg = O
	KELY=rcw_ASSERT(hst(compiler, INST_CODE_AND_| LO 
	ar>s3 K)offs_reg)));
	 argw, 63| ((ned SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_32)
			FAIL_IF(pushnst(compiler, RLWINM | S(OFFS_REG(arg)) | A(tmp_| ((n | B(T_NUMBER| );Y=rcw_- argw) << 1)));_s32 e
			FAIL_IF(pushnst(compiler, RLDI(tmp_reg, OFFS_T_NUMBER,t | A(tmp_| ((,t_s32)));
#e_s32))1 | IMASeg = tif

	/*iler, INST_CODE_AND_| LO 
	ar>s3 K)offs_reg)));
	T_NUMBER| IM}MASK	0x7f
EM_REMOV (((s(30) | A(arg) 0) | hint& ~INruct slc_CODE_AND_#>s3 K)if (SLif lo?AVED_REMOVI: (((s(3A(argI|1(0) | A(arg),jmb, tmb,w))T_NUMBER>locasrcw)#>s3 K)if (SLif lo?A0) | hinte_s32I: _s32 iC_ATTRIBUTE sljit_s32 sljit_emit_return(struct op1compiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrcw)
{
	sljit_s32 i, tmp, offs;
turn 4;
f SLJe_ptropT_?p_00000)
#defiI: 0ffs_reg;
	sljiVE_COND;

STERALLLJe_ptropTR();
	CHECK(check_sljit_emit_return(compileop1csrc, srcw));

mb, tmb,w))	if (compiler	ADJUST;
	comtr, execmb, tmb,wler	ADJUST;
	comtr, exec	if (compier->opi >STEROPnst,#opntexT_ALI>s3 K)if (SLif loG_P=rcw_ASSERT(h>s3  >T_NUT_SP O
	KELYG0)
#def_TYP,#op A(arg)T==FETCH:
OVERFLOWRT(hnst(compiler, MTLR | S(0)));
TXE) | A(SLJIT_SP)iler->locaopT<FETCH:
NOToG_PFASTBLE;, 63srcloG_P=rcT==F << 23;
	KELY!TYP,_CASTBNEEDED#opn#end	st(comp
}

#undef STACf (_LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x7fffoMASK];
	arif (SLi32_OP 23;
	KELYopT<FETCH:
NOTASSERT(KELY=rc

	if (SLJIT_p->flags & opT==FETCH:
MOV_S_ptr[-3] opi >ETCH:
MOV_U;
	}

0] = (ut_laKELY=rc

	if (SLif load_iags & opT==FETCH:
MOV_U_ptr[-3] opi >ETCH:
MOV_S;
	}

0] = inst[0] = ORIS* wMonteo     s, s expeler ignt sySegG_Pargujit_el->addr _ABS48;
	/* Separ | A4

#define;ERT(KELYf SLJe_ptrop A(arg)tr[-3]_ABS48;
	_0000100
ALT= data (argw <= SIt_type) opT_HAS_FPU:
#ifdeMOV:AS_FPU:
#ifdeMOV_P:eLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_32)
			FAIL_IF(push_FPU:
#ifdeMOV_U_p:AS_FPU:
#ifdeMOV_S_p:AASeg = tmst(compruct slc_CODE_AND_
#ifdeMOV(3A(argI|1
#define ,jmb, tmb,w))T_NUMBER>locasrcw)compier-LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	compiler->size FPU:
#ifdeMOV_U_p:ASmst(compEM_REMOV 
#ifdeMOV_U_p,	/* SeparLJIT_ADD_E32iler->_FPU:
#ifdeMOV_S_p:ASmst(compEM_REMOV 
#ifdeMOV_S_p,	/* Separ | A4

#define,rgw + ((argwde_ptr = (sljFPU:
#ifdeMOV_U8:ASmst(compEM_REMOV 
#ifdeMOV_U8,8
#define LJIT_ADD_E8iler->_FPU:
#ifdeMOV_S8:ASmst(compEM_REMOV 
#ifdeMOV_S8,8
#define  | A4

#define,rgw + ((a8iler->_FPU:
#ifdeMOV_U16:ASmst(compEM_REMOV 
#ifdeMOV_U16,0
#define LJIT_ADD_Eg) |er->_FPU:
#ifdeMOV_S16:ASmst(compEM_REMOV 
#ifdeMOV_S16,0
#define  | A4

#define,rgw + ((ag) |er->_FPU:
#ifdeNOT: tmst(compruct slc_CODE_AND_
#ifdeNOT

A(arg)  b, tmb,w))T_NUMBER>locasrcw)compier->_FPU:
#ifdeNEG: tmst(compruct slc_CODE_AND_
#ifdeNEG(3A(argI|1(G0)
#def_TYP,#op A(arg)T?01000
#defI: 0),jmb, tmb,w))T_NUMBER>locasrcw)compier->_FPU:
#ifdeIT_HALJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(hst(compruct slc_CODE_AND_
#ifdeIT_(3A(argI|1(!foMASK];
	arif (SLi32_OP 2?SEa:01000
#def),jmb, tmb,w))T_NUMBER>locasrcw)compierASSERT(hst(compruct slc_CODE_AND_
#ifdeIT_(3A(arg,jmb, tmb,w))T_NUMBER>locasrcw)compierASeg = t (_mUCCESS;
}

static SLJIT_I_64

/*EM_REMOVMASK	0x7f
TE	forL_it_swrcw)compi ~INT_AsrcloG)if (SLif loG_P(_s32 e
argw >= SIMM_M(_s32 e	return push_ASK	0x7f
TE	foUL_it_swrcw)compi ~INT_AsrcloG)if (SLif loG_P!((_s32 ef (define)) SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
#if (defined SLK	0x7f
TE	forH_it_swrcw)compi ~INT_AsrcloG)if (SLif loG_P!((_s32 ef ump->flaG_P(_s32 e
ar high_short >= (_s32 e	re
#else
		SLJI ARCH_32_64(a, TE	forH_it_swrcw)compi ~INT_AsrcloG)if (SLif loG_P!((_s32 ef ump->flic const sSK	0x7f
TE	foUH_it_swrcw)compi ~INT_AsrcloG)if (SLif loG_P!((_s32 ef ~(addr & 0xf) SLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
#if (defined SLK	0x7f
TE	foT(coit_swrcw)compi ~INT_AsrcloG)if (SLif loG_P(_s32 e
ar argw >= -0x800(_s32 e	re
#else
		SLJI ARCH_32_64(a, TE	foT(coit_swrcw)compi ~INT_srcloG)if (SLif ldefined SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_64)
#if (defined SLK	0x7f
TE	foUI_it_swrcw)compi ~INT_AsrcloG)if (SLif loG_P!((_s32 ef ~(addr p->flic cCH_32_64(a, TE	foUI_it_swrcw)compi ~INT_srcloG)if (SLif ldefined S_ATTRIBUTE sljit_s32 sljit_emit_return(struct op2compiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrc1w)
{
	sljit_s31w)fs_reg;
	sljsrc2w)
{
	sljit_s322 i, tmp, offs;
turn 4;
f SLJe_ptropT_?p_00000)
#defiI: 0ff);
	CHECK(check_sljit_emit_return(compileop2csrc, srcw));

mb, tmb,w))	if1,t_s31ww)_s32,t_s322iler	ADJUST;
	comtr, execmb, tmb,wler	ADJUST;
	comtr, exec	ifR,t_s31w|er	ADJUST;
	comtr, exec	if2,t_s322ier->loca <<
==FETCH:
UNUSEDoG_P!f SLJe_ptropTh_inst(comp
}

#undef STAC_iT_ALI>s31 K)if (SLif loG_P=rc1w_ASSERT(h>s31  >T_NUT_SP OiT_ALI>s32 K)if (SLif loG_P=rc2w_ASSERT(h>s32  >T_NUT_SP O
LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x7fffoM	arif (SLi32_OP 23;
	* wMonteo     s, s expeler ignt sySegG_Pargujit_el->addr_ABS48;
	/* Separ | A4

#define;ERTKELY=rc1

	if (SLif lend	src1w_Aizeof(sljit_sws31w|er	TKELY=rc2

	if (SLif lend	src2w_Aizeof(sljit_sws32w|er	TKELYf SLJe_ptropTh_in]_ABS48;
	_0000100
ALT= d	if (jump-KELYG0)
#def_TYP,#op)T==FETCH:
OVERFLOWRT(hnst(compiler, MTLR | S(0)));
TXE) | A(SLJIT_SP)iler->t_type) STEROPnst,#opnT_HAS_FPU:
#ifdeT(c:r	TKELYG0)
#def_TYP,#op)T==FETCH:
OVERFLOWRT(hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#def

mb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
flags &f SLJe_ptropT_800(Y=rc1
|t_s32loG)if (SLif lASSERT(KELYTE	forL_it_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	forL_it_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT(KELYTE	forH_it_swrc2,t_s322iload_iagds) : SLJIile =Psws32wff;
		buf_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2tmp_000
#de3

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	forH_it_swrcR,t_s31w| oad_iagds) : SLJIile =Psws31wff;
		buf_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2tmp_000
#de3

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT(* wRange between -1on is-32768dif
covaddreaboval->addr KELYTE	foT(coit_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w_f_ptr[1]r[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2tmp_000
#de4

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	foT(coit_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w_f_ptr[1]r[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2tmp_000
#de4

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT}r	TKELYf SLJe_ptropThSSERT(KELYTE	forL_it_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de3

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	forL_it_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de3

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT}T(hst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|1(YG0)
#def_TYP,#op)T==FG0)
#def_TYP,#
}

#unEn coRRY))T?01000
#de4I: 0),jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
f_FPU:
#ifdeT(cC: tmst(compruct slc_CODE_AND_
#ifdeT(cC(3A(arg,jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
f_FPU:
#ifdeSUB:r	TKELYG0)
#def_TYP,#op)T_SAVED_REL ST_800G0)
#def_TYP,#op)T<SAVED_REL ST_EQUALhSSERT(KELY <<
==FETCH:
UNUSEDload_iags & TE	foUL_it_swrc2,t_s322iload_iaggds) : SLJIile =P=rc2w_f_ptr[1] |= hhmst(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#defI|11000
#de2

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = 			}

	st(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#def,jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;it the fieT_ALI>s32 K)if (SLif loG_P=rc2w_>SSEaddr=rc2w_ompigw >= SIM+ 1iload_iagds) : SLJIile =P=rc2w |= hhst(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#defI|11000
#de2I|11000
#de3

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(st(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#defI|11000
#de3

mb, tmb,w))	if1,t_s31ww)_s32,t_s322i;it }
r	TKELYG0)
#def_TYP,#op)T==FETCH:
OVERFLOWRT(hhst(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#de2

mb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
flags &f SLJe_ptropT_800(Y=rc1
|t_s32loG)if (SLif lASSERT(KELYTE	forL_it_swrc2,t-_s322iload_iagds) : SLJIile =Ps-_s322i_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	forL_it_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#de3

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT(KELYTE	forH_it_swrc2,t-_s322iload_iagds) : SLJIile =Pss-_s322i_f;
		buf_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|111000
#de2I|11000
#de3

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(* wRange between -1on is-32768dif
covaddreaboval->addr KELYTE	foT(coit_swrc2,t-_s322iload_iagds) : SLJIile =P-=rc2w_f_ptr[1]r[1] |= hhst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de2tmp_000
#de4

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT}
r	TKELY <<
==FETCH:
UNUSEDoG_PG0)
#def_TYP,#op)T!=FG0)
#def_TYP,#
}

#unEn coRRY))TSERT(KELYTE	forL_it_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#de4tmp_000
#de5

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(st(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|11000
#de4

mb, tmb,w))	if1,t_s31ww)_s32,t_s322i;it }
r	TKELYTE	forL_it_swrc2,t-_s322iload_iads) : SLJIile =Ps-_s322i_f_ptr[1] |= hst(compruct slc_CODE_AND_
#ifdeT(c(3A(argI|11000
#de3

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr =};
	* wWe knowp_0000100
ALTtro valuKELindif
a_AVAILABL32_OPtems. */
#define ALT_SIT(st(compruct slc_CODE_AND_
#ifdeSUB(3A(argI|1(YG0)
#def_TYP,#op)T==FG0)
#def_TYP,#
}

#unEn coRRY))T?01000
#de5I: 0),jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
f_FPU:
#ifdeSUBC: tmst(compruct slc_CODE_AND_
#ifdeSUBC(3A(arg,jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
f_FPU:
#ifdeMULHALJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(h7fffoM	arif (SLi32_OP _in]_ABS48;
	_000
#de2IMASeg = tmags &f SLJe_ptropT)TSERT(KELYTE	forL_it_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeMUL(3A(argI|11000
#def,jmb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	forL_it_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w_f_ptr[1] |= hhst(compruct slc_CODE_AND_
#ifdeMUL(3A(argI|11000
#def,jmb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT}T(hF(push_inst(compiler, RLDI(tmp_reg, 
TXE) | A(SLJIT_SP)ilerhhst(compruct slc_CODE_AND_
#ifdeMUL(3A(arg,jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
f_FPU:
#ifdeTND:AS_FPU:
#ifdeO_HAS_CLZ:
	caseXO_HAS	* wCommut
#end is the sao     s, sLT_SIT(ags &f SLJe_ptropT_||>STEROPnst,#opn
==FETCH:
TND)TSERT(KELYTE	foUL_it_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w |= hhst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#def,jmb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	foUL_it_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w |= hhst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#def,jmb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT(KELYTE	foUH_it_swrc2,t_s322iload_iagds) : SLJIile =Psws32wff;
		buf_ptr[1] |= hhst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#de2

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	foUH_it_swrcR,t_s31w| oad_iagds) : SLJIile =Psws31wff;
		buf_ptr[1] |= hhst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#de2

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT}r	TKELYSTEROPnst,#opn
!=FETCH:
TNDoG_PG0)
OPnst,#opn
!=FETCH:
TND)= ORIS* wUnlike ortn isxoND_n isrevals iswane si/
#s as _ell1;
#end(KELYTE	foUI_it_swrc2,t_s322iload_iagds) : SLJIile =P=rc2w |= hhst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#de3

mb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr = }ERT(KELYTE	foUI_it_swrcR,t_s31w| oad_iagds) : SLJIile =P=rc1w |= hhst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#de3

mb, tmb,w))	if2,t_s322w)T_NUMBE2w)_ptr = }ERT}T(hst(compruct slc_CODE_AND_STEROPnst,#opn(3A(arg,jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;i
f_FPU:
#ifdeSHL:ex_PREFETCH:
LSH_HAS_CLZ:
	caseASH_HALJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(h7fffoM	arif (SLi32_OP _in]_ABS48;
	_000
#de2IMASeg = tmags >s32 K)if (SLif load_iads) : SLJIile =P=rc2w |= hst(compruct slc_CODE_AND_STEROPnst,#opn(3A(argI|11000
#def,jmb, tmb,w))	if1,t_s31ww)T_NUMBE2w)_ptr =}T(hst(compruct slc_CODE_AND_STEROPnst,#opn(3A(arg,jmb, tmb,w))	if1,t_s31ww)_s32,t_s322i;it (_mUCCESS;
}

static SLJIT_I_ATTRIBUTE sljit_s32 sljit_emit_return(struct op_srccompiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljsrcw)
{
	sljit_s32 i, t
	CHECK(check_sljit_emit_return(compileop_srccsrc, srcw));

sif (compiler	ADJUST;
	comtr, execsrcw)compier->t_type) opT_HAS_FPU:
#ifdeFASTBMBTURN:_inKELYFASTBLE;, 63src)ush_inst(compiler, RLWINM | S(OFF
	FAIL_IFs ((ned st[0] = ORISov_before_retslc_CODE_AND_
#ifdeMOV(3
#define ,jT_NUMBE2w)_))T_NUMBER>locasrcw)compiptr = nst(compiler, RLWINM | S(OFF
	FAIL_IFT_NUMBE2  i;it }
r	Tif

	/*iler, INST_CODE_AND_n SL;AS_CLZ:
	caseSKIPIL_IF(S_BE
#dEUFASTBMBTURN:_inst(comp
}

#undef STACf_CLZ:
	caseturn 1;
_L1:Cf_CLZ:
	caseturn 1;
_L2:Cf_CLZ:
	caseturn 1;
_L3:Cf_CLZ:
	caseturn 1;
_ONCE: tmst(compruct prefeypect_s32 op, srcw)compiert (_mUCCESS;
}

static SLJIT_I_ATTRIBUTE sljit_s32 sljit_emit_return(starg_define R_  u/sture_type)
ins inst
	CHECoffs_MASKmit_return(coarg_define R_  u/stif

	if UCCESS;if
_map be ]JIT_I_ATTRIBUTE sljit_s32 sljit_emit_return(starg_ regi_define R_  u/sture_type)
ins inst
	CHECoffs_MASKmit_return(coarg_ regi_define R_  u/stif

	if UCCESS;fif
_map be ]JIT_I_ATTRIBUTE sljit_s32 sljit_emit_return(stmpileop_custo_compiler *compiler, sljit_s32 inp
	void *),
/* i s x, sljit_s32 _ERROR();
	CHECK(check_sljit_set_context(compileop_custo_creg, argw)) 
/* i s x, sIF(push tif

	/*iler, INST_CODE_AND_*(;
	sljit_*)*/

/* 64 bi;-------------------------------------------------------------- */
/*  Entry, exit    -------- */

/o                                                     ------------------------------------------------------------- */

/* s/l - store2_64(a, FLOA Separ opT_(20

#defineI|1(YoM	arif (SLF32_OP 2f;
6)K_STORE	STWELEC00
#P();

sd).SL tmouble)1(YoM	arif (SLF32_OP 2?
sd).SL :tmouble) SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_64)
#if (defined SLK	0x7f
FLOA ST_NUeturr, exe (6t_sw))));
#else
	FAIc cCH_32_64(a, FLOA ST_NUeturr, exe (it_sw))));
#else
	FAI SLJIT_CONFIG_PPC_32 LITT#deENDIANIG_PPC_64)LITT#deENDIAN SLK	0x7f
FLOA ST_NUeturr, exe;
	W (it_sw))));
#else
	FAI LK	0x7f
FLOA ST_NUeturr, exe;HI (3t_sw))));
#else
	FAIc cCH_32_64(a, FLOA ST_NUeturr, exe;
	W (3t_sw))));
#else
	FAIc K	0x7f
FLOA ST_NUeturr, exe;HI (it_sw))));
#else
	FAI Lfined SLfined};

PC_32 && SLJIT_CONFItoreNLINE sif (SLiNLINjit_emit_return(stmpilefop1ler,v
	F_from_f64compiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrcw)
{
	sljit_s32 i, tKELY=rc

	if (SLJIT_p->fl* wWe can
ignnsiguctitemporary_inst/ unsigonructiotack fromquired).  */

/of view1;
#endov_before_retsljit_creg, argw)FLOA Separ opT_|1
#define w)T_NUFMBER,t_s3w)compw)T_NUMBER| IMM(src  >T_NUFMBER;if (rLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(opi >STEROPnst,#opntexnst(compiler, MTLR | S(0)));#opT==FETCH:

		V_S_pUFMOM_FNFI? FCTIWZendiCTIDZT_|1FA(SLJIFMBER| );FB3| ((ned Sgs & opT==FETCH:

		V_SWUFMOM_FNF 23;
	KELYFASTBLE;, 63 << addr =dov_before_retsljit_creg, argw)20

#definew)T_NUFMBER,tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER| IMM(ist(compe_retsljit_creg, argw)
#define _|1
#define w)mb, tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER|tr =}T(hst(compruct sljit_creg, argw)20

#definew)T_NUFMBER,tmb, tmb,w))T_NUMBER|_Flocal_sizenst(compiler, MTLR | S(0)));FCTIWZe|1FA(SLJIFMBER| );FB3| ((ned rgw <= SIMM_MFASTBLE;, 63 << addr =mmediate(compiler, tmp_reg, argw)T_NUMBER,tFLOA ST_NUeturr, exepush_inst(compiler, STDUX | S(SLJIT_FIW) | FS(SLJIFMBER| );B(0)));
	}

#if T_NUMBER| lerhhst(compruct sljit_creg, argw)/* Separ | 
#define w)mb, tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER|tr RT(offs == -(slji <<

	if (SLJIT_er->loca <<
K)) {
		argw &= ddr = b,fs_reg = OFFloca <<wed SLJIT_CONFIG_PPC_32 && SLJIT_CONFIG_PPC_32)
			FAIL_IF(push_inst(compiler, RLWINM | S(OFFS_REG(arg)) | A(tmp_ << ad| B(T_NUMBER| );Y b,fs- argw) << 1))); <<wed
			FAIL_IF(push_inst(compiler, RLDI(tmp_reg, OFFS_T_NUMBER,t | A(tmp_ <<  tmb,w)));
#emb,w))		offs_reg = tmp b,fs >T_NUMBER;ifT}T(hF(push_i b,fs > | A(tmp_ << ;if (put_label-T_ALI <<
K)	argw &= dG_P! <<wed Sh_i b,fs > <<
K)	argw &=;Sh_i b,s >0;ifT}T(hF(pu= ORIS* wThisg & R/
stgardless _e havetif (SLJIT1 ortif (SLJIT01;
#end(mmediate(compiler, tmp_reg, argw)T_NUMBER,t <<we); tmp b,fs >T_NUMBER;ifT}T(}h tif

	/*iler, INST_CODE_AND_T_FIW) | FS(SLJIFMBER| );B( <<
K)	argw &= d#if  <<we); }reNLINE sif (SLiNLINjit_emit_return(stmpilefop1ler,v
f64_from_swcompiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrcw)
{
	sljit_s32 i, LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
		SLJIT_ASSERT(A_reg;
	sljmb,_ *)SFASTBLE;, 63 << I?  <<
:>T_NUFMBER;i tKELY=rc

	if (SLif load_iKELYSTEROPnst,#opn
==FETCH:

		V_FNFUFMOM_S_ptr[-3srcw_Aizeof(sljit_srcw;r =mmediate(compiler, tmp_reg, argw)T_NUMBER,tcompiptr =src  >T_NUMBER;if (put_laKELYSTEROPnst,#opn
==FETCH:

		V_FNFUFMOM_S_pt23;
	KELYFASTBLE;, 63src)ush_inst(compiler, RLWINM | S(OFF/* HWIL_IFs ((d| B(T_NUMBER|ned st[0] r =dov_before_retsljit_creg, argw)/* Separ | A4

#define_|1
#define w)T_NUMBER,t_s3w)compw)T_NUMBER| IMM(src  >T_NUMBER;if (rkKELYFASTBLE;, 63src)uabel-ov_before_retsljit_creg, argw)
#define ,j_s3w)if (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER| IMM(ov_before_retsljit_creg, argw)20

#define_|1
#define w)T_NUFMBER,tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER| IMM (put_lMM(ov_before_retsljit_creg, argw)20

#define_|1
#define w)T_NUFMBER,t_s3w)compw)T_NUMBER| IMzenst(compiler, MTLR | S(0)));FCFIDe|1FA(mb,_ | );FB3SLJIFMBER|)_er->loca <<
K)if (SLJIT_rhhst(compruct sljit_creg, argw)FLOA Separ opTw)T_NUFMBER,tmb, tmb,w))T_NUMBER|_Fl7fffoM	arif (SLF32_OP _inif

	/*iler, INST_CODE_AND_FRSPe|1FA(mb,_ | );FB3mb,_ |	if UCCESS;
}

#undef STAC_IF(pus(A_reg;
	sljmb,_ *)SFASTBLE;, 63 << I?  <<
:>T_NUFMBER;ix sljit_sw ) veretsdgn*)SR;i tKELY=rc

	if (SLif load_immediate(compiler, tmp_reg, argw)T_NUMBER,tcomp ^ #else
		SL| IMM(src  >T_NUMBER;if	) veretsdgn*)S0;if (put_laKELY!FASTBLE;, 63src)uabel-ov_before_retsljit_creg, argw)
#define  | A4

#define_|1
#define w)T_NUMBER,t_s3w)compw)T_NUMBER| IMM(src  >T_NUMBER;if (rk* wFirb, tt/ pecialtmouble f-------- */

/valuedif
co/

/* 6ed: (i^538000) |utsxoN (i^3R|)_
	1) Thg.mouble precisr. *signat has exactly 538/
#dprecisr. ,)soxucti
   r 3e opc. strevants
	1) ucti
   r 3e opc.of on */value.hThg. ssult of xoN i^3Rnstruction). as add----#else
		SL
	1) uoxucti) |ut, whi */shiftsLindinuoxucti0
#eptr[1]r[1] range.hTo getxuctier,vere - s-------
	1)  */

/value, _e ne */
#isub

/act i^53800i^3Rnfromquctier,

/* 6ed/value.h
#ennst(compiler, ADDIS | D(tmp_reg) | A(aT_NUMBE2  
	args = 0x433L| IMMKELY) veretsdgnRT(hnst(compiler, MTLR | S(0)));XOR) | AIFs ((d| B(T_NUMBER| = 0x8	SL| IMMov_before_retsljit_creg, argw)
#define ,jT_NUMBE2w)if (SLJIT1MM(offs))),
FLOA ST_NUeturr, exe_HIw)T_NUMBER| IMMov_before_retsljit_creg, argw)
#define ,jT_NUMBER,tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exe;
	Ww)T_NUMBE2  IMMnst(compiler, ADDIS | D(tmp_reg) | A(aT_NUMBE1  
	args = 0x8	SL| IMMov_before_retsljit_creg, argw)20

#define_|1
#define w)T_NUFMBER,tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER| IMMov_before_retsljit_creg, argw)
#define ,jT_NUMBER,tif (SLJIT1MM(offs))),
FLOA ST_NUeturr, exe;
	Ww)T_NUMBE2  IMMnst(compe_retsljit_creg, argw)20

#define_|1
#define w)T_NUFMBE2w)if (SLJIT1MM(offs))),
FLOA ST_NUeturr, exew)T_NUMBER| IMzenst(compiler, MTLR | S(0)));FSUBe|1FA(mb,_ | );FA(SLJIFMBER| );FB3T_NUFMBE2|)_er->loca <<
K)if (SLJIT_rhhst(compruct sljit_creg, argw)FLOA Separ opTw)T_NUFMBER,tmb, tmb,w))T_NUMBER|_Fl7fffoM	arif (SLF32_OP _inif

	/*iler, INST_CODE_AND_FRSPe|1FA(mb,_ | );FB3mb,_ |	if UCCESS;
}

#undef STAC_IFAPI_FUNC32 emitif (SLiNLINjit_emit_return(stmpilefop1lemlcompiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljsrc1w)
{
	sljit_s31w)fs_reg;
	sljsrc2w)
{
	sljit_s322 i, tKELY=rc1

	if (SLJIT_p->flov_before_retsljit_creg, argw)FLOA Separ opT_|1
#define w)T_NUFMBER,t_s31,t_s31ww)T_NUMBER| IMM(src1  >T_NUFMBER;if (rmags >s32 K)if (SLJIT_p->flov_before_retsljit_creg, argw)FLOA Separ opT_|1
#define w)T_NUFMBE2))	if2,t_s322w)T_NUMBE2  IMM(src2  >T_NUFMBE2;T(}h tif

	/*iler, INST_CODE_AND_FCMPU_|1CRD(4| );FA(src1| );FB3| (2e); }re_ATTRIBUTE sljit_s32 sljit_emit_return(stmpilefop1compiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrcw)
{
	sljit_s32 i, tmp, offs;
db,_ ;0);
	CHECK(check_s(offs ==COMPI#de -(slji(if (SLF32_OP_ASSE
#ifloG_P!(20

#define_f_pt4n(3A(egi_[(inp_flab(stmrror IMMWELEC00
#P1_OPERATION_WITH_
	CHEScsrc, srcw));

mb, tmb,w))	if (compi O
	KELYG0)
OPnst,#opn
==FETCH:

		V_FNFUFMOM_F_ptr[-oM	^=rif (SLF32_OP O
	mb,_ *)SFASTBLE;, 63 << I?  <<
:>T_NUFMBER;i tKELY=rc

	if (SLJIT_p->flov_before_retsljit_creg, argw)FLOA Separ opT_|1
#define w)db,_ ,jsrcw)compw)T_NUMBER| IMM(src  >db,_ ;0x}orkt_type) STEROPnst,#opnT_HAS_FPU:
#ifde
		V_FNFUFMOM_F_p:r[-oM	^=rif (SLF32_OP O(h7fffoM	arif (SLF32_OP 23;
	enst(compiler, MTLR | S(0)));FRSPe|1FA(mb,_ | );FB3s ((ned st	breaktr =};
	* wFallqucrough.h
#en_FPU:
#ifdeMOV_FNF:_inKELYsrc ! >db,_ hSSERT(KELY <<_ *! >T_NUFMBERtr[-3]nst(compiler, MTLR | S(0)));FMRe|1FA(mb,_ | );FB3s ((ned st	[0] r =d	 b,_ *)Ssrctr =};
	breaktr _FPU:
#ifdeNEG_FNF:_innst(compiler, MTLR | S(0)));FNEGe|1FA(mb,_ | );FB3s ((ned stbreaktr _FPU:
#ifdeABS_FNF:_innst(compiler, MTLR | S(0)));FABSe|1FA(mb,_ | );FB3s ((ned stbreaktr }r->loca <<
K)if (SLJIT_rhhov_before_retsljit_creg, argw)FLOA Separ opT)  b,_ ,jmb, tmb,w))T_NUMBER|	if UCCESS;
}

#undef STAC}re_ATTRIBUTE sljit_s32 sljit_emit_return(stmpilefop2compiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	sljsrc1w)
{
	sljit_s31w)fs_reg;
	sljsrc2w)
{
	sljit_s322 i, tmp, offs;
db,_ ;0);
	CHECK(check_sljit_set_context(compilefop2csrc, srcw));

mb, tmb,w))	if1,t_s31ww)_s32,t_s322iler	ADJUST;
	comtr, execmb, tmb,wler	ADJUST;
	comtr, exec	ifR,t_s31w|er	ADJUST;
	comtr, exec	if2,t_s322ier->mb,_ *)SFASTBLE;, 63 << I?  <<
:>T_NUFMBE2;i tKELY=rc1

	if (SLJIT_p->flov_before_retsljit_creg, argw)FLOA Separ opT_|1
#define w)T_NUFMBER,t_s31,t_s31ww)T_NUMBER| IMM(src1  >T_NUFMBER;if (rmags >s32 K)if (SLJIT_p->flov_before_retsljit_creg, argw)FLOA Separ opT_|1
#define w)T_NUFMBE2))	if2,t_s322w)T_NUMBE2  IMM(src2  >T_NUFMBE2;T(}h tt_type) STEROPnst,#opnT_HAS_FPU:
#ifdeT(c_FNF:_innst(compiler, MTLR | S(0)));WELEC00
#P();

FT(cS

FT(c)e|1FA(mb,_ | );FA(src1| );FB3| (2e)ed stbreaktr
f_FPU:
#ifdeSUB_FNF:_innst(compiler, MTLR | S(0)));WELEC00
#P();

FSUBS

FSUB)e|1FA(mb,_ | );FA(src1| );FB3| (2e)ed stbreaktr
f_FPU:
#ifdeMUL_FNF:_innst(compiler, MTLR | S(0)));WELEC00
#P();

FMULS

FMUL)e|1FA(mb,_ | );FA(src1| );FC3| (2e};

FMUL
#eliFC as src2 */)ed stbreaktr
f_FPU:
#ifdeDIV_FNF:_innst(compiler, MTLR | S(0)));WELEC00
#P();

FDIVS

FDIV)e|1FA(mb,_ | );FA(src1| );FB3| (2e)ed stbreaktr }r->loca <<
K)if (SLJIT_rhhov_before_retsljit_creg, argw)FLOA Separ opT) T_NUFMBE2))mb, tmb,w))T_NUMBER|	if_mUCCESS;
}

static SLJIT_I_64

/*WELEC00
#P------------------------------------------------------------ */
/*  Entry, exit   Othslj*/

/* 64 b                                                    ------------------------------------------------------------- */

/* s/l - store_ATTRIBUTE sljit_s32 sljit_emit_return(stmpilefab,_entercompiler *compiler, sljit_s32 op, sljit_s32 mb, tyhort;

	mb,wOR();
	CHECK(check_sljit_set_context(compilefab,_enterct_s32 op, mb, tmb,wller	ADJUST;
	comtr, execmb, tmb,wlerSIMM_MFASTBLE;, 63 << a_inif

	/*iler, INST_CODE_AND_MFFAIL_D3 << awork whMemory.h
#ennst(compiler, ADDIS | D(tmp_MFFAIL_D3T_NUMBE2  i;itst(compruct slc_CODE_AND_
#ifdeMOV(3
#define ,jmb, tmb,w))T_NUMBER>locaT_NUMBE2w)_ptr------------------------------------------------------------- */
/*  Entry, exit   CoAPI64 balj*/

/* 64 b                                              ------------------------------------------------------------- */

/* s/l - store_ATTRIBUTE sljit_s32 sljitmpiler *complabel*turn(stmpilelabelcompiler *compiler, sljit_s32 op i, tmmpiler *complabel *label;0);
	CHECK(che_PTeck_sljit_s_PTect_context(compilelabelct_s32 op lerSIMM_Mds) : SLJIlab,_label G_Pds) : SLJIlab,_label->w)))
==Fds) : SLJI_ERRORinif

	/*ds) : SLJIlab,_labelerSIlabel Aizempiler *complabel*)ensure_abufct_s32 op, s))));
#mpiler *complabel i;itPTe_nst(comp!label ;ix elelabelclabel,*ds) : SLi;itst(complabelerT_INLINE s_op_meit_sarg_boab(ASK];
ture_type)
0) | i, tm_type) 0) | _HAS_FPU:
#ifdeEQUAL: tmst(comp(12d
		2gw) <<2d
		16i;i
f_FPU:
#ifdeNOdeEQUAL: tmst(comp(4d
		2gw) <<2d
		16i;i
f_FPU:
#ifdeL STHAS_CLZ:
	caseSIGeL STHASmst(comp(12d
		2gw) <<0d
		16i;i
f_FPU:
#ifdeGREATEReEQUAL: t_CLZ:
	caseSIGeGREATEReEQUAL: tmst(comp(4d
		2gw) <<0d
		16i;i
f_FPU:
#ifdeGREATER: t_CLZ:
	caseSIGeGREATERHASmst(comp(12d
		2gw) <<1d
		16i;i
f_FPU:
#ifdeL STeEQUAL: t_CLZ:
	caseSIGeL STeEQUAL: tmst(comp(4d
		2gw) <<1d
		16i;i
f_FPU:
#ifdeL STeFNF:_inst(comp(12d
		2gw) <<(4d+ xffff;
6i;i
f_FPU:
#ifdeGREATEReEQUALeFNF:_inst(comp(4d
		2gw) <<(4d+ xffff;
6i;i
f_FPU:
#ifdeGREATEReFNF:_inst(comp(12d
		2gw) <<(4d+ 1ffff;
6i;i
f_FPU:
#ifdeL STeEQUALeFNF:_inst(comp(4d
		2gw) <<(4d+ 1ffff;
6i;i
f_FPU:
#ifdeOVERFLOW:
f_FPU:
#ifdeMUL_OVERFLOW:
fnst(comp(12d
		2gw) <<3d
		16i;i
f_FPU:
#ifdeNOdeOVERFLOW:
f_FPU:
#ifdeMUL_NOdeOVERFLOW:
fnst(comp(4d
		2gw) <<3d
		16i;i
f_FPU:
#ifdeEQUALeFNF:_inst(comp(12d
		2gw) <<(4d+ 2ffff;
6i;i
f_FPU:
#ifdeNOdeEQUALeFNF:_inst(comp(4d
		2gw) <<(4d+ 2ffff;
6i;i
f_FPU:
#ifdeUN#deEREDeFNF:_inst(comp(12d
		2gw) <<(4d+ 3ffff;
6i;i
f_FPU:
#ifdeOdeEREDeFNF:_inst(comp(4d
		2gw) <<(4d+ 3ffff;
6i;i
f

/ault:_inffs == -(slji0) |T_SAVED_REJUMP G_P0) |T<SAVED_RECALLLCDECLlerhhst(comp(20d
		2gwtr }r}re_ATTRIBUTE sljit_s32 sljitmpiler *compjump*turn(stmpilejumpcompiler *compiler, sljit_s32 op, sljit_s32 0) | i, tmmpiler *compjump *jump;ix sljitit_sboab(ASK];
;0);
	CHECK(che_PTeck_sljit_s_PTect_context(compilejumpct_s32 op, 0) | i;i
fboab(ASK];
 Aiarg_boab(ASK];
t0) |Tf_ptr[|_Fl7fff!boab(ASK];
ORinif

	/*NULL;i
fjump Aizempiler *compjump*)ensure_abufct_s32 op, s))));
#mpiler *compjump i;itPTe_nst(comp!jump ;ix elejumpcjump,*ds) : SL, 0) |
K)if (SLREWRITA
#deJUMP ;ix0) |
K=_ptr[work whIn
rgw, _e don't ne */
#iton */uctiargujit_el->add7fff0) |T<AVED_REJUMPORinjump->_ABS48;
	/Se
		D 2LJIT_CONFIG_PPC_64 PASTeENTRYeT(cR_TOECALLIG_PPC_64)PASTeENTRYeT(cR_TOECALL)dd7fff0) |T>SAVED_RECALLORinjump->_ABS48;
	/Se
ALL;irgw <= SIPTe_nst(compmpileer,

_reg, argw)T_NUCALLLREG(30 i;itPTe_nst(compiler, RLWINM | S(OFF
	CTAIL_IFT_NUCALLLREG  i;itjump->add *)Sds) : SLJI_ERR;itPTe_nst(compiler, RLWINM | S(OFFBCCTAIL_boab(ASK];
 |ff0) |T>SAVED_REFASTBCALLI? fI: 0) i;itst(compjump;i}re_ATTRIBUTE sljit_s32 sljitmpiler *compjump*turn(stmpilecallcompiler *compiler, sljit_s32 op, sljit_s32 0) |)fs_reg;
	sljarg_0) |sOR();
	CHECK(che_PTeck_sljit_s_PTect_context(compilecallcds) : SL, 0) |,jarg_0) |sO) O
LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0xPTe_nst(compcall__tyh_argscds) : SL, arg_0) |s,*NULLned rgw <= SLJIT_CONFIG_PPC_64 VERBOSEIG_PPC_64)VERBOSEi ~IN	||T_CONFIG_PPC_64 ARGUMENT_
	CHESIG_PPC_64)ARGUMENT_
	CHESize s) : SLJI_kip_t_cons*)SR;irgw <= SIst(compext(compilejumpct_s32 op, 0) | AC}re_ATTRIBUTE sljit_s32 sljit_emit_return(stmpileijumpcompiler *compiler, sljit_s32 op, sljit_s32 0) |, sljit_s32 _rcw)
{
	sljit_s32 i, tmmpiler *compjump *jump*)SNULL;is_reg;
	sljsrc_ ;0);
	CHECK(check_sljit_set_context(compileijumpct_s32 op, 0) |

sif (compiler	ADJUST;
	comtr, execsrcw)compier->KELYFASTBLE;, 63src)uabeLJIT_CONFIG_PPC_64 PASTeENTRYeT(cR_TOECALLIG_PPC_64)PASTeENTRYeT(cR_TOECALL)ddd7fff0) |T>SAVED_RECALLO23;
	enst(compiler, MTLR | S(0)));OAIL_IFs ((d| B(T_NUCALLLREG  = B >s3(ned st	src_   >T_NUCALLLREG;ifT}T(hF(push_isrc_   >srctrIF(push_src_   >srctrIFeg = t  ut_laKELY=rc

	if (SLif load_i* wThe_lajumps artier,vere - 
#ijump/callj*/

/* 64 b  when possiblal->addrjump Aizempiler *compjump*)ensure_abufct_s32 op, s))));
#mpiler *compjump i;it	nst(comp!jump ;ixx elejumpcjump,*ds) : SL, JUMPeT(cR ;ixxjump->u.target  >srcw 2LJIT_CONFIG_PPC_64 PASTeENTRYeT(cR_TOECALLIG_PPC_64)PASTeENTRYeT(cR_TOECALL)ddd7fff0) |T>SAVED_RECALLORinnjump->_ABS48;
	/Se
ALL;irgw <= hhov_before_reter,

_reg, argw)T_NUCALLLREG(30 i;it	src_   >T_NUCALLLREG;if (put_label-ov_before_retslc_CODE_AND_
#ifdeMOV(3
#define ,jT_NUCALLLREG(30))T_NUMBER>locasrcw)compiptr =src_   >T_NUCALLLREG;if (ennst(compiler, ADDIS | D(tmp_M	CTAIL_IFsrc_ )| IMMKELYjump ixxjump->add *)Sds) : SLJI_ERR;itif

	/*iler, INST_CODE_AND_nCCTAIL_(20d
		2gw |ff0) |T>SAVED_REFASTBCALLI? fI: 0) AC}re_ATTRIBUTE sljit_s32 sljit_emit_return(stmpileicallcompiler *compiler, sljit_s32 op, sljit_s32 0) |)fs_reg;
	sljarg_0) |scfs_reg;
	sljsrcw)
{
	sljit_s32 i, t
	CHECK(check_sljit_emit_return(compileicallcds) : SL, 0) |,jarg_0) |scasrcw)compiptr
LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x7fff=rc

	if (SLJIT_p->flADJUST;
	comtr, execsrcw)compierl-ov_before_retslc_CODE_AND_
#ifdeMOV(3
#define ,jT_NUCALLLREG(30))T_NUMBER>locasrcw)compiptr =src  >T_NUCALLLREG;if (ennst(compcall__tyh_argscds) : SL, arg_0) |s,*&>s3(nd rgw <= SLJIT_CONFIG_PPC_64 VERBOSEIG_PPC_64)VERBOSEi ~IN	||T_CONFIG_PPC_64 ARGUMENT_
	CHESIG_PPC_64)ARGUMENT_
	CHESize s) : SLJI_kip_t_cons*)SR;irgw <= SIst(compext(compileijumpct_s32 op, 0) |

sif (compiJIT_I_ATTRIBUTE sljit_s32 sljit_emit_return(stmpileop_SK];
tumpiler *compiler, sljit_s32 op, sljit_s32 srcfs_reg;
	sljmb, tyhort;

	mb,w)fs_reg;
	slj0) | i, tmre_type)
insw)) |ut A(arg) clab(s, ) vere;is_reg;
	sljsaved opi >op;is_reg;
	wjsaved  b,fs > <<wff);
	CHECK(check_sljit_emit_return(compileop_SK];
tsrc, srcw));

mb, tmb,w))0) | i;i	ADJUST;
	comtr, execmb, tmb,wlerSLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	if (argw <= 0x7 |ut A(arg AizoM	arif (SLi32_OP 2?)/* Separ :3
#define trIF(push7 |ut A(arg Ai
#define trIFw <= SIopi >STEROPnst,#opntexins AizoM	<AVED_RET(coG_PFASTBLE;, 63 << ad?  <<
:>T_NUMBE2;i tKELYoM	>SAVED_RET(coG_Pa <<
K)if (SLJIT__rhhov_before_retsljit_creg, argw)7 |ut A(arg |1
#define w)T_NUMBER,tmb, tmb,w))T_NUMBER|	if_m) vere*)S0;ifclab(s*)S0;i tm_type) 0) |Tf_ptr[|_HAS_FPU:
#ifdeL STHAS_CLZ:
	caseSIGeL STHASmbreaktr
f_FPU:
#ifdeGREATEReEQUAL: t_CLZ:
	caseSIGeGREATEReEQUAL: tm) vere*)S1d stbreaktr
f_FPU:
#ifdeGREATER: t_CLZ:
	caseSIGeGREATERHASmclab(s*)S1d stbreaktr
f_FPU:
#ifdeL STeEQUAL: t_CLZ:
	caseSIGeL STeEQUAL: tmclab(s*)S1d st) vere*)S1d stbreaktr
f_FPU:
#ifdeEQUAL: tmclab(s*)S2d stbreaktr
f_FPU:
#ifdeNOdeEQUAL: tmclab(s*)S2d st) vere*)S1d stbreaktr
f_FPU:
#ifdeOVERFLOW:
f_FPU:
#ifdeMUL_OVERFLOW:
fnclab(s*)S3d stbreaktr
f_FPU:
#ifdeNOdeOVERFLOW:
f_FPU:
#ifdeMUL_NOdeOVERFLOW:
fnclab(s*)S3d st) vere*)S1d stbreaktr
f_FPU:
#ifdeL STeFNF:_inclab(s*)S4d+ xd stbreaktr
f_FPU:
#ifdeGREATEReEQUALeFNF:_inclab(s*)S4d+ xd st) vere*)S1d stbreaktr
f_FPU:
#ifdeGREATEReFNF:_inclab(s*)S4d+ 1d stbreaktr
f_FPU:
#ifdeL STeEQUALeFNF:_inclab(s*)S4d+ 1d st) vere*)S1d stbreaktr
f_FPU:
#ifdeEQUALeFNF:_inclab(s*)S4d+ 2d stbreaktr
f_FPU:
#ifdeNOdeEQUALeFNF:_inclab(s*)S4d+ 2d st) vere*)S1d stbreaktr
f_FPU:
#ifdeUN#deEREDeFNF:_inclab(s*)S4d+ 3d stbreaktr
f_FPU:
#ifde#deEREDeFNF:_inclab(s*)S4d+ 3d st) vere*)S1d stbreaktr
f

/ault:_inffs ==UNREACHA
#d(ed stbreaktr }r->nst(compiler, ADDIS | D(tmp_MFCAIL_D3if

	 IMMnst(compiler, ADDIS | D(tmp_S_REG(arg))if

d| B(if

d| ((18000clab(s))s- argw) <<31d
		6w) <<31d
		R|)_er->loca) vereRT(hnst(compiler, MTLR | S(0)));XOR)arg))if

d| B(if

d| 0x1)_er->locaoM	<AVED_RET(c 23;
	KELY!a <<
K)if (SLJIT__rhhnst(comp
}

#undef STACfhst(compruct sljit_creg, argw)) |ut A(arg) insw)mb, tmb,w))T_NUMBER|_FlocSLJIT_CONFIG_PPC_64 VERBOSEIG_PPC_64)VERBOSEi ~IN	||T_CONFIG_PPC_64 ARGUMENT_
	CHESIG_PPC_64)ARGUMENT_
	CHESize s) : SLJI_kip_t_cons*)SR;irgw <= >loca <<
K)if (SLJIT_rhhst(compurn(compileop2csrc, srcw)saved opw)mb, tsaved  b,f))T_NUMBER>locaT_NUMBE2w)_ptrhst(compurn(compileop2csrc, srcw)saved opw)mb, t0w)mb, t0w)T_NUMBE2w)_ptr---_ATTRIBUTE sljit_s32 sljit_emit_return(stmpilecmovcompiler *compiler, sljit_s32 op, sljit_s32 0) |)fs_reg;
	sljmb,_ nswfs_reg;
	sljsrcw)
{
	sljit_s32 i, t
	CHECK(check_sljit_emit_return(compilecmovct_s32 op, 0) |

mb,_ nswasrcw)compiptr
hst(compurn(compilecmov_genericct_s32 op, 0) |

mb,_ nswasrcw)compi;tr---_ATTRIBUTE sljit_s32 sljit_emit_return(stmpileit_compiler *compiler, sljit_s32 op, sljit_s32 0) |)fs_reg;
	slj nswfs_reg;
	sljit_w)
{
	sljitit_2 i, tmp, offs;
it_ASK];
;0x sljitit_s MTLff);
	CHECK(check_sljit_emit_return(compileit_creg, argw)0) |

 nswait_w)it_2 _er->loca0) |
K)if (SLeturPOSTh_inst(comp
}

#uK(c=UNSUPPORTED;i tm_type) 0) |Tf_ptr[|_HAS_FPU:
#ifdeMOV:AS_FPU:
#ifdeMOV_P:eLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_32)
			FAIL_IF(push_FPU:
#ifdeMOV_U_p:AS_FPU:
#ifdeMOV_S_p:AASeg = tmit_ASK];
 Ai
#define trstbreaktr
LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	compiler->size FPU:
#ifdeMOV_U_p:ASmit_ASK];
 Ai/* Separd stbreaktr
f_FPU:
#ifdeMOV_S_p:ASmit_ASK];
 Ai/* Separd ;
	KELY!a0) |
K)if (SLeturSTOREloG_P!(0) |
K)if (SLi32_OP hSSERT(KELYit_
K)) {
		argw &= r =d	it_ASK];
 |= A4

#define;ERT([0] r =d	st(comp
}

#uK(c=UNSUPPORTED;i =};
	breaktrptr = (sljFPU:
#ifdeMOV_U8:AS_FPU:
#ifdeMOV_S8:ASmit_ASK];
 Ai
#define d stbreaktr
f_FPU:
#ifdeMOV_U16:ASmit_ASK];
 Ai
#define d stbreaktr
f_FPU:
#ifdeMOV_S16:ASmit_ASK];
 Ai
#define  | A4

#define;ERTbreaktr
f

/ault:_inffs ==UNREACHA
#d(ed stit_ASK];
 Ai
#define trstbreaktr }r->loca!a0) |
K)if (SLeturSTOREl)
d	it_ASK];
 |= 
#define er->locaffs ==UNLIKELYYit_
K)) {
		argw &=  23;
	KELYit_2*! >0_rhhnst(comp
}

#uK(c=UNSUPPORTED;i t>loca0) |
K)if (SLeturSUPP_rhhnst(comp
}

#undef STAC st) b,s >updated  ata_[(inp_fla) b,s[it_ASK];
 | _MASKED]erl-ov_beforiler, MTLR | S(0)));INSTBCst,
TND_DST( MTL t0w)if

d| B(it_
K)	argw &= d#if  | A(tmp_it_))| IMM (put_l23;
	KELYit_2*>rgw >= SIM||Tit_2*<eturn push_hhnst(comp
}

#uK(c=UNSUPPORTED;i t>l b,s >updated  ata_[(inp_fla) b,s[it_ASK];
]tr
LJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_64)
	compiler->size-T_ALIl b,s&i/* SAL4

#dT_800(it_2*f_pt3)*! >0_rhhnst(comp
}

#uK(c=UNSUPPORTED;iptr = (sl>loca0) |
K)if (SLeturSUPP_rhhnst(comp
}

#undef STAC stov_beforiler, MTLR | S(0)));INSTBCst,
TND_DST( MTL t0w)if

d| B(it_
K)	argw &= d#iit_sit_2 _)tr }r->loca(it_ASK];
 & 
#define T_800(0) |Tf_ptr[|_==FETCH:
MOV_S8a_inif

	/*iler, INST_CODE_AND_/* HBarg))if

d| B(if

	if UCCESS;
}

#undef STAC}re_ATTRIBUTE sljit_s32 sljit_emit_return(stmpilefit_compiler *compiler, sljit_s32 op, sljit_s32 0) |)fs_reg;
	sljf nswfs_reg;
	sljit_w)
{
	sljitit_2 i, tmp, offs;
it_ASK];
;0x sljitit_s MTLff);
	CHECK(check_sljit_emit_return(compilefit_creg, argw)0) |

f nswait_w)it_2 _er->loca0) |
K)if (SLeturPOSTh_inst(comp
}

#uK(c=UNSUPPORTED;i tlocaffs ==UNLIKELYYit_
K)) {
		argw &=  23;
	KELYit_2*! >0_rhhnst(comp
}

#uK(c=UNSUPPORTED;iM (put_l23;
	KELYit_2*>rgw >= SIM||Tit_2*<eturn push_hhnst(comp
}

#uK(c=UNSUPPORTED;i }r->loca0) |
K)if (SLeturSUPP_rhhst(comp
}

#undef STAC sit_ASK];
 AiFLOA Separ 0) | AC->loca!a0) |
K)if (SLeturSTOREl)
d	it_ASK];
 |= 
#define er->locaffs ==UNLIKELYYit_
K)) {
		argw &=  23;
	K b,s >updated  ata_[(inp_fla) b,s[it_ASK];
 | _MASKED]erl-if

	/*iler, INST_CODE_AND_INSTBCst,
TND_DST( MTL t20

#definew)fif

d| B(it_
K)	argw &= d#if  | A(tmp_it_))|;i }r->l b,s >updated  ata_[(inp_fla) b,s[it_ASK];
]tr-if

	/*iler, INST_CODE_AND_INSTBCst,
TND_DST( MTL t20

#definew)fif

d| B(it_
K)	argw &= d#iit_sit_2 _;i}re_ATTRIBUTE sljit_s32 sljitmpiler *comper,

*turn(stmpilecr,

_ompiler *compiler, sljit_s32 op, sljit_s32 mb, tyhort;

	mb,w tyhort;

	inrt;value i, tmmpiler *compcr,

jit_,

_; tmp, offs;
db,_ ;0);
	CHECK(che_PTeck_sljit_s_PTect_context(compilecr,

_reg, argw)mb, tmb,w))inrt;value ler	ADJUST;
	comtr, execmb, tmb,wlerSIt_,

_ Aizempiler *comper,

*)ensure_abufct_s32 op, s))));
#mpiler *comper,

 i;itPTe_nst(comp!t_,

_ ;ix elecr,

_re,

_,*ds) : SLi;i->mb,_ *)SFASTBLE;, 63 << I?  <<
:>T_NUMBE2;T(PTe_nst(compmpileer,

_reg, argw) b,_ ,jinrt;value ler >loca <<
K)if (SLJIT_rhhPTe_nst(compmpileslc_CODE_AND_
#ifdeMOV(3
#define ,jmb, tmb,w))T_NUMBER>locaT_NUMBE2w)_pptr
hst(compt_,

_; }re_ATTRIBUTE sljit_s32 sljitmpiler *comp|ut label*turn(stmpile|ut labelcompiler *compiler, sljit_s32 op, sljit_s32 mb, tyhort;

	mb,wOR();tmpiler *comp|ut label *|ut label; tmp, offs;
db,_ ;0);
	CHECK(che_PTeck_sljit_s_PTect_context(compile|ut labelct_s32 op, mb, tmb,wller	ADJUST;
	comtr, execmb, tmb,wlerSI|ut label Aizempiler *comp|ut label*)ensure_abufct_s32 op, s))));
#mpiler *comp|ut label i;itPTe_nst(comp!|ut label ;ix ele|ut labelc|ut label,*ds) : SL, 0i;i->mb,_ *)SFASTBLE;, 63 << I?  <<
:>T_NUMBE2;TLJIT_CONFIG_PPC_64 && SLJIT_CONFIG_PPC_32)
			FAIL_IF(pushPTe_nst(compmpileer,

_reg, argw) b,_ ,j0AIL_IF(pushPTe_nst(compiler, RLWINM | S(OFFmb,_ |	if ds) : SLJI_ERR += 4d rgw <= SIMM_M <<
K)if (SLJIT_rhhPTe_nst(compmpileslc_CODE_AND_
#ifdeMOV(3
#define ,jmb, tmb,w))T_NUMBER>locaT_NUMBE2w)_pptr
hst(com